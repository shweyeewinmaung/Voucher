<html>
	<head>
		<title>Voucher POS</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		
		<script src="../../js/jquery.min.js"></script>
		<script src="../../js/jquery.dropotron.min.js"></script>
		<script src="../../js/skel.min.js"></script>
		<script src="../../js/skel-layers.min.js"></script>
		<script src="../../js/init.js"></script>
		
			<link rel="stylesheet" href="../../css/skel.css" />
			<link rel="stylesheet" href="../../css/style.css" />
			<link rel="stylesheet" href="../../css/style-wide.css" />
			 <style>#skel-layers-inactiveWrapper{ height:0%!important;}</style>
	</head>
	<body>

		<!-- Wrapper -->
			

				<!-- Header and Logon and Menu Start -->
						<div id="header" class="skel-panels-fixed"><div id="logo"><h1 style="font-size:1.2em;"><a href="../../Enfanto">Voucher POS</a></h1></div>
						<nav id="nav">
							<ul>
								<li class="active"><a href="../../../Enfanto">Home</a></li>
                                <li>User
                                    <ul style="background:#000; width:10%; ">
                                         <li style="padding:5px 5px 10px 5px;border-bottom:1px solid#ccc; text-align:center"><a href="../../User/List">All User</a></li>
                                         <li style="padding:5px 5px 10px 5px;border-bottom:1px solid#ccc; text-align:center"><a href="../../User/Register">Add User</a></li>
                                    </ul>
                                </li>
                                 <li>Customer
                                    <ul style="background:#000; width:10%; ">
                                         <li style="padding:5px 5px 10px 5px;border-bottom:1px solid#ccc; text-align:center"><a href="../../Customer/List">All Customer</a></li>
                                         <li style="padding:5px 5px 10px 5px;border-bottom:1px solid#ccc; text-align:center"><a href="../../Customer/Register">Add Customer</a></li>
                                         
                                    </ul>
                                </li>
                                 <li>Supplier
                                    <ul style="background:#000; width:10%; ">
                                         <li style="padding:5px 5px 10px 5px;border-bottom:1px solid#ccc; text-align:center"><a href="../../Supplier/List">All Supplier</a></li>
                                         <li style="padding:5px 5px 10px 5px;border-bottom:1px solid#ccc; text-align:center"><a href="../../Supplier/Register">Add Supplier</a></li>
                                    </ul>
                                </li>
                                 <li>Category
                                    <ul style="background:#000; width:10%; ">
                                         <li style="padding:5px 5px 10px 5px;border-bottom:1px solid#ccc; text-align:center"><a href="../../Category/List">All Category</a></li>
                                         <li style="padding:5px 5px 10px 5px;border-bottom:1px solid#ccc; text-align:center"><a href="../../Category/Register">Add Category</a></li>
                                    </ul>
                                </li>
                                 <li>Product
                                    <ul style="background:#000; width:10%; ">
                                         <li style="padding:5px 5px 10px 5px;border-bottom:1px solid#ccc; text-align:center"><a href="../../Product/List">All Product</a></li>
                                         <li style="padding:5px 5px 10px 5px;border-bottom:1px solid#ccc; text-align:center"><a href="../../Product/Register">Add Product</a></li>
                                    </ul>
                                </li>
                                 <li>Voucher
                                    <ul style="background:#000; width:10%; ">
                                         <li style="padding:5px 5px 10px 5px;border-bottom:1px solid#ccc; text-align:center"><a href="../../Voucher/List">All Voucher</a></li>
                                         <li style="padding:5px 5px 10px 5px;border-bottom:1px solid#ccc; text-align:center"><a href="../../Voucher/Add">Add Voucher</a></li>
                                    </ul>
                                </li>
                                <li ><a href="../../All/LogOut"><i class="fa fa-wrench"></i> Log Out</a></li>
                              	<li> <?php echo "Welcome : ".$_SESSION['SESS']['User']['User_Name'];?> : :<?php echo $_SESSION['SESS']['User']['User_Role'];?></li>
							</ul>
						</nav>
					</div><!----------Logo and Header and Menu End------------>
				

				

	
	</body>
</html>