<?php require_once("template/sidebarfileindex.php"); ?>	

<div class="wrapper style1">
				<!-- Extra -->
					<div id="extra">
						<div class="container">
							<div class="row no-collapse-1">
								<section class="4u"> <a href="Product/List" class="image featured"><img src="images/pic01.jpg" alt=""></a>
									<div class="box"><a href="Product/List" class="button">Product</a> </div></section>
								<section class="4u"> <a href="Category/List" class="image featured"><img src="images/pic02.jpg" alt=""></a>
									<div class="box"><a href="Category/List" class="button">Category</a> </div>
								</section>
								<section class="4u"> <a href="Voucher/List" class="image featured"><img src="images/pic03.jpg" alt=""></a>
									<div class="box"><a href="Voucher/List" class="button">Voucher</a> </div>
								</section>
							</div>
							<div class="row no-collapse-1">
								<section class="4u"> <a href="User/List" class="image featured"><img src="images/pic01.jpg" alt=""></a>
									<div class="box"><a href="User/List" class="button">User</a> </div>
								</section>
								<section class="4u"> <a href="Customer/List" class="image featured"><img src="images/pic02.jpg" alt=""></a>
									<div class="box"><a href="Customer/List" class="button">Customer</a> </div>
								</section>
								<section class="4u"> <a href="Supplier/List" class="image featured"><img src="images/pic03.jpg" alt=""></a>
									<div class="box"><a href="Supplier/List" class="button">Supplier</a> </div>
								</section>
							</div>
						</div>
					</div>
					<div id="copyright"><div class="container"><div class="copyright"><p>Voucher POS System</p></div></div></div>
			</div><!------End Wrapper------>

	