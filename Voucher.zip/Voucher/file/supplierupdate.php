<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
include("../library/permissionforEnD.php");
include("../dal/dal_supplier.php");


if(isset($_POST['btnUpdate']) && isset($_POST['Supplier_ID']))
{
	$Supplier_ID=Clean($conn,$_POST['Supplier_ID']);
	$Supplier_Name=Clean($conn,$_POST['Supplier_Name']);
	$Supplier_Phone=Clean($conn,$_POST['Supplier_Phone']);
	$Supplier_Email=Clean($conn,$_POST['Supplier_Email']);
	$Supplier_Address=Clean($conn,$_POST['Supplier_Address']);
	
	UpdateSupplier($conn,$Supplier_ID, $Supplier_Name, $Supplier_Phone, $Supplier_Email,$Supplier_Address);
	print "<script language=\"JavaScript\">window.location.href=\"../../Supplier/List \";</script>";
}

if (isset($_GET['Supplier_ID']) && $_GET['Supplier_ID']!="")
{	
	$Supplier_ID=Clean($conn,$_GET['Supplier_ID']);
	$ret=GetSupplierDataBySupplierID($conn,$Supplier_ID);
	$num=mysqli_num_rows($ret);
}
?>
<?php require_once("../template/sidebarfileforEnD.php");?>

<!-- Wrapper -->
			<div class="wrapper style1" >
				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major"><h2>Edit Supplier</h2></header>
							<form method="post">
                    		
							<?php
                            if($num>0)
                            {
                                    $row=mysqli_fetch_array($ret);
                        ?>
                        	<div class="form-group" style="display:none;">
                                  <label for="Supplier_ID">ID:</label>
                                 <input type="text" name="Supplier_ID" value="<?php echo $row['Supplier_ID']; ?>">
                              </div>
                            <div class="form-group">
                              <label for="Supplier_Name">Name:</label>
                              <input required type="text" class="form-control" id="Supplier_Name" name="Supplier_Name" value="<?php echo $row['Supplier_Name'];  ?>">
                            </div>
                            <div class="form-group">
                              <label for="Supplier_Phone">Phone:</label>
                              <input required type="text" class="form-control" id="Supplier_Phone" name="Supplier_Phone" value="<?php echo $row['Supplier_Phone'];  ?>">
                            </div>
                                <div class="form-group">
                              <label for="Supplier_Email">Email:</label>
                              <input type="email" class="form-control" id="Supplier_Email" name="Supplier_Email" value="<?php echo $row['Supplier_Email'];  ?>">
                            </div>
                           
                              
                           <div class="form-group">
                              <label for="Supplier_Address">Address:</label><br>
                              <textarea name="Supplier_Address" rows="5"><?php echo $row['Supplier_Address'];  ?></textarea>
                             
                            </div>
                            
                            
                             <?php } ?> 
                           	 <br />
                             <button type="submit" class="btn btn-danger" name="btnUpdate" style="margin-left:30%; " >Edit</button>
                             <a href="../../Supplier/List"> <button  type="button" class="btn btn-default" name="btnDelete" style="margin-left:1%; ">Back</button></a>
                          
                          </form>
						</section>
					</div>
				<!-- /Page -->

				
                <div id="copyright"><div class="container"><div class="copyright"><p>Voucher POS System</p></div></div></div>
	</div><!-----End Wrapper-------->


  <!-- REQUIRED JS SCRIPTS -->

   <!-- REQUIRED JS SCRIPTS -->
 <script type="text/javascript">
     $(function(){
   $('#datepicker').datepicker({
      format: 'd-M-yyyy',
	  todayHighlight:true
    });
});
        </script>
      
  <!--  jQuery -->
<script type="text/javascript" src="../js2/jquery-1.11.3.min.js"></script>

<!-- Isolated Version of Bootstrap, not needed if your site already uses Bootstrap -->
<link rel="stylesheet" href="../css2/bootstrap-iso.css" />

<!-- Bootstrap Date-Picker Plugin -->
<script type="text/javascript" src="../js2/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="../css2/bootstrap-datepicker3.css"/>