<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
include("../library/permissionforEnD.php");
include("../dal/dal_user.php");


if(isset($_POST['btnUpdate']) && isset($_POST['User_ID']))
{
	$User_ID=Clean($conn,$_POST['User_ID']);
	$User_Name=Clean($conn,$_POST['User_Name']);
	$User_Role=Clean($conn,$_POST['User_Role']);
	$User_Email=Clean($conn,$_POST['User_Email']);
	$User_Password=Clean($conn,$_POST['User_Password']);
	$Lastin_Date=GetCurrentDate();
		
	UpdateUser($conn,$User_ID, $User_Name,$User_Role,$User_Email,$User_Password,$Lastin_Date);
	print "<script language=\"JavaScript\">window.location.href=\"../../User/List \";</script>";
}

if (isset($_GET['User_ID']) && $_GET['User_ID']!="")
{	
	$User_ID=Clean($conn,$_GET['User_ID']);
	$ret=GetUserDataByUserID($conn,$User_ID);
	$num=mysqli_num_rows($ret);
}
?>
<?php require_once("../template/sidebarfileforEnD.php");?>

<!-- Wrapper -->
			<div class="wrapper style1" >
				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major"><h2>Edit User</h2></header>
							<form method="post">
                    		
							<?php
                            if($num>0)
                            {
                                    $row=mysqli_fetch_array($ret);
                        ?>
                        	<div class="form-group" style="display:none;">
                                  <label for="User_ID">ID:</label>
                                 <input type="text" name="User_ID" value="<?php echo $row['User_ID']; ?>">
                              </div>
                            <div class="form-group">
                              <label for="User_Name">Name:</label>
                              <input type="text" class="form-control" id="User_Name" name="User_Name" value="<?php echo $row['User_Name'];  ?>">
                            </div>
                            <div class="form-group">
                            <label for="User_Role">Type:</label><br />
                              <select class="form-control" id="User_Role" name="User_Role">
                              	<option><?php echo $row['User_Role'];  ?></option>
                                <option>Super Admin</option>
                                <option>Manager</option>
                                <option>Admin</option>
                                
                               </select>
                               </div>
                                <div class="form-group">
                              <label for="User_Email">Email:</label>
                              <input type="email" class="form-control" id="User_Email" name="User_Email" value="<?php echo $row['User_Email'];  ?>">
                            </div>
                           
                              
                           <div class="form-group">
                              <label for="User_Password">Old Password:</label>
                              <?php echo $row['User_Password'];  ?>
                            </div>
                           <div class="form-group">
                              <label for="User_Password">New Password:</label>
                              <input type="password" class="form-control" id="User_Password" name="User_Password" value="<?php echo $row['User_Password'];  ?>">
                            </div>
                            
                            
                             <?php } ?> 
                           		<br />
                             <button type="submit" class="btn btn-danger" name="btnUpdate" style="margin-left:30%; " >Edit</button>
                             <a href="../../User/List"> <button  type="button" class="btn btn-default" name="btnDelete" style="margin-left:1%; ">Back</button></a>
                          
                          </form>
						</section>
					</div>
				<!-- /Page -->

				
                <div id="copyright"><div class="container"><div class="copyright"><p>Voucher POS System</p></div></div></div>
	</div><!-----End Wrapper-------->

