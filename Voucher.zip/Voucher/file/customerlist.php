<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
include("../library/permission.php");
include("../dal/dal_customer.php");
include("../dal/dal_product.php");
include("../dal/dal_category.php");

$ret=GetCustomerDataByCustomer($conn);
$num=mysqli_num_rows($ret);
?>
<?php require_once("../template/sidebarfile.php");?>

    <!-- Wrapper -->
			<div class="wrapper style1" >
				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major"><h2>Customer List</h2></header>
							<div class="table-responsive">
                                <table id="customer_data" class="table table-striped table-bordered dt-responsive nowrap" width="98%" cellspacing="0">
                                     <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Phone</th>
                                            <th>Email</th>
                                            <th>Address</th>
                                            
                                                                     
                                            <th>Edit</th>
                                            <th>Delete</th>
                                            <th>Voucher Data</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                         <?php  $u=1;
                                            while($row=mysqli_fetch_array($ret)){	?>  
                                        <tr>
                                            <th><?php echo $u; ?></th>
                                            <th><?php echo $row['Customer_ID']; ?></th>
                                            <th><?php echo $row['Customer_Name']; ?></th>
                                            <th><?php echo $row['Customer_Phone']; ?></th>
                                            <th><?php echo $row['Customer_Email']; ?></th>
                                            <th><?php echo $row['Customer_Address']; ?></th>
                                           
                                            
                                             <th><a href="../Customer/Edit/<?php echo $row['Customer_ID']; ?>"><img src="../img/wrench-screwdriver.png"  width="20" height="20"/></a></th>
                                            <th><a href="../Customer/Remove/<?php echo $row['Customer_ID']; ?>">
                            <img src="../img/cross-script.png" width="20" height="20" /></a></th>
                                           
                                                <th > 
                                          
                                                <?php 
                                                     $y=1;
                                                    $ret1=GetVoucherDataByCustomerID($conn,$row['Customer_ID']);
                                                    $num1=mysqli_num_rows($ret1);
                                                    
                                                    while($row1=mysqli_fetch_array($ret1))
                                                    {
                                                        ?>
                                                       <?php
                                                      
                                                        $ret2=GetVoucherDataByVoucherID($conn,$row1['Voucher_ID']);
                                                        $num2=mysqli_num_rows($ret2);
                                                        while($row2=mysqli_fetch_array($ret2))
                                                        {
                                                            $ret3=GetProductDataByProductID($conn,$row2['Product_ID']);
                                                            $num3=mysqli_num_rows($ret3);
                                                            $row3=mysqli_fetch_array($ret3);
                                                            
                                                            $ret4=GetCategoryDataByCategoryID($conn,$row3['Category_ID']);
                                                            $num4=mysqli_num_rows($ret4);
                                                            $row4=mysqli_fetch_array($ret4);
                                                  
                                                  ?> 
                                                  
                                               <p style=" border-bottom:2px dotted#C00;background:#ccc;"> 
                                               <font style="color:#300; font-weight:bold;"> No : <?php echo $y;?></font><br>
                                               
                                               <span style="background:#996;">Date : <?php  echo  $row1['Voucher_Date']; ?></span><br><br>
                                                
                                                Voucher No : <font style="color:#300; font-weight:bold;"><?php  echo  $row1['Voucher_ID']; ?></font><br>
                                                Order Code :  <font style="color:#300; font-weight:bold;"><?php echo   $row1['Order_Code']; ?></font><br>
                                                Product Name :  <font style="color:#300; font-weight:bold;"><?php echo $row3['Product_Name'];  ?></font><br>
                                                Category Name :  <font style="color:#300; font-weight:bold;"><?php echo $row4['Category_Name']; ?></font><br>
                                                Quantity :  <font style="color:#300; font-weight:bold;"><?php echo $row2['Quantity']; ?></font><br>
                                                Selling Price :  <font style="color:#300; font-weight:bold;"><?php echo $row2['Selling_Price']; ?></font><br>
                                                Discount :  <font style="color:#300; font-weight:bold;"><?php if($row2['Discount_Price']==0){echo "0";}else{echo $row2['Discount_Price']; }  ?> </font><br>
                                                Amount :  <font style="color:#300; font-weight:bold;"><?php if($row2['Discount_Price']==0){echo $row2['Quantity']*$row2['Selling_Price'];}else{echo $row2['Quantity']*$row2['Discount_Price']; }?></font><br><br>
                                                
                                                 </p>
                                            <?php $y=$y+1; 
                                             } ?>
                                           
                                            <font style="color:#600; font-weight:bold;">Total Amount: <?php echo $row1['Amount']; ?> </font><br>
                                            <font style="color:#600; font-weight:bold;">Delivery Price :<?php echo $row1['Delivery_Price'];?></font><br> <br><p style="border-bottom:2px  dashed#333"></p>
                                             <?php
                                                
                                             } ?>
                                          
                                            </th>
                                        </tr>
                                       <?php $u=$u+1;  } ?> 
                                       </tbody>
                                 </table> 
                </div>  <!----table responsive------->
						</section>
					</div>
				<!-- /Page -->

				
                <div id="copyright"><div class="container"><div class="copyright"><p>Voucher POS System</p></div></div></div>
	</div><!-----End Wrapper-------->


  <!-- REQUIRED JS SCRIPTS -->
<link rel="stylesheet" href="../css3/bootstrap.min.css">
<link rel="stylesheet" href="../css3/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="../css3/responsive.bootstrap.min.css">
<script src="../js3/jquery-1.12.4.js"></script>  
<script src="../js3/jquery.dataTables.min.js"></script>  
<script src="../js3/dataTables.bootstrap.min.js"></script> 
<script src="../js3/dataTables.responsive.min.js"></script>  
<script src="../js3/responsive.bootstrap.min.js"></script> 
<script>
    $(document).ready(function() {
    $('#customer_data').DataTable();
} );
    </script>
  <style>
  #customer_data_wrapper{
	  width:98%;
  }
  #customer_data_filter{
	 margin-right:10%;
  }
  
  div.dataTables_wrapper div.dataTables_paginate {
	  text-align:left;
  }
  </style>