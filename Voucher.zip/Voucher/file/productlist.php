<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
include("../library/permission.php");
include("../dal/dal_product.php");
include("../dal/dal_category.php");
include("../dal/dal_supplier.php");
include("../dal/shoppingCartFunction.php");

$ret=GetProductDataByProduct($conn);
$num=mysqli_num_rows($ret);
?>
<?php require_once("../template/sidebarfile.php");?>
	<!-- Wrapper -->
			<div class="wrapper style1" >
				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major"><h2>Add Voucher</h2></header>
							<div class="col-md-8">
            			<h3 style="color:#F06;">Product List</h3>
                  	<div class="table-responsive">
                    <form  method="get" enctype="multipart/form-data" style="width:90%;">
                    <table id="product_data" class="table table-striped table-bordered dt-responsive nowrap"  cellspacing="0">
                         <thead>
                            <tr>
                                <th>No</th>
                               
                                <th>Name</th>
                                 <th>ADD</th>
                                <th>SKU Code</th>
                                <th>Category Name</th>
                                <th>Original Price</th>
                                <th>Selling Price</th>
                                                            
                               
                                
                            </tr>
                            </thead>
                            <tbody>
                             <?php  $u=1;
                                while($row=mysqli_fetch_array($ret)){	?>  
                            <tr>
                                <th><?php echo $u; ?></th>
                               
                                <th><?php echo $row['Product_Name']; ?></th>
                                <th><a href="../Voucher/Add?Product_ID=<?php echo $row['Product_ID'];?>">Add to Detail</a></th>
                                <th><?php echo $row['Product_Code']; ?></th>
                                <th><?php echo GetCategoryNameByCategoryID($conn,$row['3']); ?></th>
                                <th><?php echo $row['Original_Price']; ?></th>
                                <th><?php echo $row['Selling_Price']; ?></th>
                                
                                
                                
                            </tr>
                           <?php $u=$u+1;  } ?> 
                           </tbody>
                     </table>
                    </form> 
                    </div> <!-----------table responsive End ------>   
                </div> <!-----------col-md-8 End ------>
                
				<!------------Detail------------------->
                <div class="col-md-4">
                <h3 style="color:#F06;">Product Detail</h3>
                
                  	<div class="table-responsive"  >
                    <?php
					if (isset($_GET['Product_ID']) && $_GET['Product_ID']!="")
					{	
						$Product_ID=Clean($conn,$_GET['Product_ID']);
						$ret=GetProductDataByProductID($conn,$Product_ID);
						$num=mysqli_num_rows($ret);
					}
					?>
                    <form action="../Voucher/Add" method="post" enctype="multipart/form-data"  style="width:100%;">
                
							<?php
                            if($num>0)
                            {
                                    $row=mysqli_fetch_array($ret);
                        ?>
                    <table id="product_data_detail" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" >
                         <thead>
                            <tr style="display:none">
                               
                                <th>ID</th>
                                 <th><input style="display:none;" type="text" readonly id="Product_ID" name="Product_ID"  value="<?php echo $row['Product_ID']; ?>"/></th>
                            </tr>
                            <tr>
                                <th>Name</th>
                                <th><input style="display:none;" type="text" readonly id="Product_Name" name="Product_Name"  value="<?php echo $row['Product_Name']; ?>"/><font style="color:#F06;"><?php echo $row['Product_Name']; ?></font></th>
                             </tr>
                             <tr>
                                <th>SKU Code</th>
                                <th><input style="display:none;" type="text" readonly id="Product_Code" name="Product_Code" value="<?php echo $row['Product_Code']; ?>" /><font style="color:#F06;"><?php echo $row['Product_Code']; ?></font></th>
                             </tr>
                             <tr>
                                <th>Category Name</th>
                                 <th><input style="display:none;" type="text" readonly id="Category_ID" name="Category_ID" value="<?php echo GetCategoryNameByCategoryID($conn,$row['3']); ?>" /><font style="color:#F06;"><?php echo GetCategoryNameByCategoryID($conn,$row['3']); ?></font></th>
                             </tr>
                             <tr>
                                <th>Original Price</th>
                                <th><input  style="display:none;"type="text" readonly id="Product_Code" name="Product_Code" value="<?php echo $row['Original_Price']; ?>" /><font style="color:#F06;"><?php echo $row['Original_Price']; ?></font></th>
                              </tr>
                              <tr>
                                <th>Selling Price</th>
                                <th><input style="display:none;" type="text" readonly id="Product_Code" name="Product_Code" value="<?php echo $row['Selling_Price']; ?>" /><font style="color:#F06;"><?php echo $row['Selling_Price']; ?></font></th>
                               </tr>
                               <tr>
                                 <th>Discount</th>
                                 <th><input type="text"  id="Discount_Price" name="Discount_Price" value="0"/></th> 
                                <tr>
                                 <th>Quantity</th>
                                 <th><input type="text"  id="Quantity" name="Quantity" /></th>  
                                </tr>
                                 <tr>
                                 <th>Supplier</th>
                                 <th>
                                  <select class="form-control" id="Supplier_ID" name="Supplier_ID">
                                
                                  <?php 
                                              $retSup=GetSupplierDataBySupplier($conn);
                                                $numSup=mysqli_num_rows($retSup);
                                            while($rowSup=mysqli_fetch_array($retSup))
                                                {
                                                    echo "<option value=".$rowSup['Supplier_ID'].">" . $rowSup['Supplier_Name'] . "</option>";
                                                }
                                    ?>
                                   
                                   </select>
                               </th>  
                                </tr>
                                <tr>                        
                                	<th>ADD</th>
                                	<th><input type="submit" value="Add to Voucher" name="AddDetail" />
                          
                            	</tr>
                            </thead>
                           
                          
                     </table>
                       <?php } ?> 
                    </form>    
                </div>  
                </div>
                <!-------Detail End------------------------>
                
                <!-------------Shopping Cart-------------------------->
<?php
$shoppingCart = new ShoppingCart();
	if(isset($_POST['AddDetail'])){
		
	@$Product_ID=$_POST['Product_ID'];
	@$Discount_Price=$_POST['Discount_Price'];
	@$Quantity=$_POST['Quantity'];
	@$Supplier_ID=$_POST['Supplier_ID'];
	
	if($Discount_Price=="0"){$statusOK=$shoppingCart->Insert($Product_ID, $Quantity,$Supplier_ID);}
	else{$statusOK=$shoppingCart->Insert1($Product_ID,$Discount_Price, $Quantity,$Supplier_ID);}
	}
		
	if(@$_GET['Action']=="Remove")
	{
		$Product_ID=$_GET['Product_ID'];
		$shoppingCart->Remove($Product_ID);
	}
	else if (@$_GET['Action']=="Clear")
	{
		//Function Call to Clear "ShoppingCart"
		$shoppingCart->Clear();
	}
	?>
    <div class="col-md-12" >
<h3 style="color:#F06; margin-left:35%;">Voucher List</h3>

     
     	<div class="table-responsive" id="printableArea">
                    <form method="get">
                 <input type="button" onclick="printDiv('printableArea')" value="Print!" />
                 <table id="voucher" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="1" >
                      	<tr>
                        	<td>Name</td>
                            <td>Category </td>
                            <td> Code</td>
                            <td> Supplier Name</td>
                            <td> Price</td>
                            <td> Discount</td>
                            <td>Quantity </td>
                            <td> Amount</td>
                            <td>Remove</td>
                                                    
                        </tr>
                                  
				<?php
					$size=count(@$_SESSION['ShoppingCart']);
					
					$totalAmount=0;
					
					if ($size==0)
					{
				?>
                <tr>
                	<td style="text-align:center;" colspan="8">
						<h3><font style="color:#F06;">Voucher is empty.</font></h3>
                    </td>
               </tr>
                    <?php
					}//end of "if"


					for($i=0;$i<$size;$i++)
					{			
						$Product_ID=$_SESSION['ShoppingCart'][$i]['Product_ID'];
						@$Discount_Price=$_SESSION['ShoppingCart'][$i]['Discount_Price'];
						$Quantity=$_SESSION['ShoppingCart'][$i]['Quantity'];
						@$Supplier_ID=$_SESSION['ShoppingCart'][$i]['Supplier_ID'];								
						if($Discount_Price==0)
						{
							$sql="SELECT * FROM tbl_product WHERE Product_ID='$Product_ID'";	
						
							$result=mysqli_query($conn,$sql);
							$row=mysqli_fetch_array($result);
							
							$amount= $Quantity * $row['Selling_Price'];
							$totalAmount+=$amount;
							
							if ($i%2==0)
								echo "<tr>";
							else
								echo "<tr class='alt'>";
						}
						else
						{
							$sql="SELECT * FROM tbl_product WHERE Product_ID='$Product_ID'";	
						
							$result=mysqli_query($conn,$sql);
							$row=mysqli_fetch_array($result);
							
							$amount= $Quantity * $Discount_Price;
							$totalAmount+=$amount;
							
							if ($i%2==0)
								echo "<tr>";
							else
								echo "<tr class='alt'>";
						}
						
                ?>
           <tr>
                                
                               
                                <td><strong style="color:#F06;"><?php echo $row['Product_Name']; ?></strong></td> 
                                <td><strong style="color:#F06;"><?php echo GetCategoryNameByCategoryID($conn,$row['3']); ?></strong></td> 
                                <td><strong style="color:#F06;"v><?php echo $row['Product_Code']; ?></strong></td> 
                                <td><strong style="color:#F06;"v><?php echo GetSupplierNameBySupplierID($conn,$Supplier_ID); ?></strong></td> 
                                <td><strong style="color:#F06;"><?php echo $row['Selling_Price']; ?></strong></td> 
                                <td><strong style="color:#F06;"><?php if($Discount_Price==""){echo "0";}else{echo $Discount_Price;} ?></strong></td> 
                                <td><strong style="color:#F06;"><?php echo $Quantity; ?></strong></td>   
                                <td> <strong style="color:#F06;"><?php echo $amount; ?></strong></td>
                                <td><a href="../Voucher/Add?Product_ID=<?php echo $Product_ID; ?>&Action=Remove">x</a></td> 
             </tr>
            <?php             
                    }
            ?>
            	<tr>
                	<td colspan="7" style="text-align:right">Total Amount :</td>
                	<td colspan="2">
	                    
                    	
                    	<strong> <?php echo $totalAmount; ?></strong>
                    </td>
                </tr>
                <tr>
                	
                	<td colspan="9">
	                     <a href="../Voucher/ConfirmVoucher">Check Out</a>&nbsp;
                    	<a href="../Voucher/Add?Action=Clear">All Clear</a>&nbsp;
                    	
                    </td>
                </tr>
            </table></form>      
                </div>  
                </div>
                
             	<!----------End Shopping Cart------------------>
						</section>
					</div>
				<!-- /Page -->

				
                <div id="copyright"><div class="container"><div class="copyright"><p>Voucher POS System</p></div></div></div>
	</div><!-----End Wrapper-------->
     

  <!-- REQUIRED JS SCRIPTS -->
<link rel="stylesheet" href="../css3/bootstrap.min.css">
<link rel="stylesheet" href="../css3/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="../css3/responsive.bootstrap.min.css">
<script src="../js3/jquery-1.12.4.js"></script>  
<script src="../js3/jquery.dataTables.min.js"></script>  
<script src="../js3/dataTables.bootstrap.min.js"></script> 
<script src="../js3/dataTables.responsive.min.js"></script>  
<script src="../js3/responsive.bootstrap.min.js"></script> 
<script>
    $(document).ready(function() {
    $('#product_data').DataTable();
} );
    </script>
  <style>
 
   #product_data_wrapper{
	  width:90%;
  }
  #product_data_filter{
	 margin-right:10%;
  }
  
  div.dataTables_wrapper div.dataTables_paginate {
	  text-align:left;
  }
    #voucher_wrapper{
	  width:90%;
  }
  #voucher_filter{
	 margin-right:10%;
  }
  
  div.dataTables_wrapper div.dataTables_paginate {
	  text-align:left;
  }
  @media screen and (min-width:767px){
	
  #product_data_detail_wrapper{
	  width:25%;
  }
  #product_data_filter{
	 margin-right:10%;
  }
  
}
@media screen and (max-width:767px){
	  #product_data_detail_wrapper{
	  width:100%;
  }
  
  
	
}
  </style>
  
   <script>
   function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
}
   
   </script>