<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
include("../library/permission.php");
include("../dal/dal_supplier.php");

if (isset($_POST['Supplier_Name']))
{	
	$Supplier_ID=AutoID($conn, 'tbl_supplier','Supplier_ID','C-',6);
	$Supplier_Name=Clean($conn,$_POST['Supplier_Name']);
	$Supplier_Phone=Clean($conn,$_POST['Supplier_Phone']);
	$Supplier_Email=Clean($conn,$_POST['Supplier_Email']);
	$Supplier_Address=Clean($conn,$_POST['Supplier_Address']);
	
	$ret=GetSupplierDataBy_SupplierName($conn,$Supplier_Name);
		
	$num=mysqli_num_rows($ret);
	if($num>0)
	{
		$_SESSION['Supplier_Name']="Exist";
	}else{
		InsertSupplier($conn,$Supplier_ID, $Supplier_Name, $Supplier_Phone, $Supplier_Email,$Supplier_Address);
		$_SESSION['Supplier_Name']="Success";
	}
}
?>
<?php require_once("../template/sidebarfile.php");?>

    <!-- Wrapper -->
			<div class="wrapper style1" >
				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major"><h2>Add Supplier</h2></header>
								<form method="post">
                    		
                           <font style="color:red; font-size:18px; line-height:50px;">
							<?php
                                if(@$_SESSION['Supplier_Name']=="Success"){ echo "Name is Added"; unset($_SESSION['Supplier_Name']);}
                             ?>
                            <?php 
                                if(@$_SESSION['Supplier_Name']=="Exist"){ echo "Already Exist!"; unset($_SESSION['Supplier_Name']);}
                            ?></font>
                            <div class="form-group">
                              <label for="Supplier_Name">Name:</label>
                              <input type="text" class="form-control" id="Supplier_Name" name="Supplier_Name" required>
                            </div>
                            <div class="form-group">
                              <label for="Supplier_Phone">Phone:</label>
                              <input type="text" class="form-control" id="Supplier_Phone" name="Supplier_Phone" required>
                            </div>
                           <div class="form-group">
                              <label for="Supplier_Email">Email:</label>
                              <input type="email" class="form-control" id="Supplier_Email" name="Supplier_Email">
                            </div>
                           <div class="form-group">
                              <label for="Supplier_Address">Address:</label><br>
                              <textarea name="Supplier_Address" rows="5"></textarea>
                             
                            </div>
                           
                            <br />
                            <button type="submit" class="btn btn-default" name="btnAdd" style="margin-left:30%;" >Entry</button>
                          
                          </form>
						</section>
					</div>
				<!-- /Page -->

				
                <div id="copyright"><div class="container"><div class="copyright"><p>Voucher POS System</p></div></div></div>
	</div><!-----End Wrapper-------->


  