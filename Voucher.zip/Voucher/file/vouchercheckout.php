<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
include("../library/permission.php");
include("../dal/dal_product.php");
include("../dal/dal_category.php");
include("../dal/dal_user.php");
include("../dal/dal_customer.php");

$size=count(@$_SESSION['ShoppingCart']);					
$totalAmount=0;
$size=count(@$_SESSION['ShoppingCart']);
	

for($i=0;$i<$size;$i++)
{			
	$Product_ID=$_SESSION['ShoppingCart'][$i]['Product_ID'];
	$Quantity=$_SESSION['ShoppingCart'][$i]['Quantity'];
	$Supplier_ID=$_SESSION['ShoppingCart'][$i]['Supplier_ID'];
	@$Discount_Price=$_SESSION['ShoppingCart'][$i]['Discount_Price'];
	
	
	$sql="SELECT * FROM tbl_product WHERE Product_ID='$Product_ID'";	
	$result=mysqli_query($conn,$sql) ;
	$row=mysqli_fetch_array($result);
	
	if($Discount_Price==0){$amount=$Quantity*$row['Selling_Price'];}else{$amount=$Quantity*$Discount_Price;}
	$totalAmount+=$amount;
}
/*********************************************************************/
	
if (isset($_POST['submitted']))
{	
	/*********************************************************************/					
	$User_ID=$_SESSION['SESS']['User']['User_ID'];
	
	$Customer_ID=AutoID($conn, 'tbl_customer','Customer_ID','C-',6);
	$Customer_Name=Clean($conn,$_POST['Customer_Name']);
	$Customer_Phone=Clean($conn,$_POST['Customer_Phone']);
	$Customer_Email=Clean($conn,$_POST['Customer_Email']);
	$Customer_Address=Clean($conn,$_POST['Customer_Address']);
	
	
	
	
	$Voucher_Date=Clean($conn,$_POST['Voucher_Date']);
	$Payment_Status=Clean($conn,$_POST['Payment_Status']);
	$Order_Code=Clean($conn,$_POST['Order_Code']);
	$Status=Clean($conn,$_POST['Status']);
	$Order_Code=Clean($conn,$_POST['Order_Code']);
	$Delivery_Price=Clean($conn,$_POST['Delivery_Price']);
	
	
	/*******************************************************************/
	$Voucher_ID=$_POST['Voucher_ID'];
	
	/*********************************************************************/
	
	$ret=GetCustomerDataBy_CustomerPhone($conn,$Customer_Phone);
	$row1=mysqli_fetch_array($ret);
	$Customer_ID1=$row1['Customer_ID'];	
	$num=mysqli_num_rows($ret);
	if($num>0)
	{
		
		
		
		$voucherinsert=	"INSERT INTO `tbl_voucher` " . 
							"(Voucher_ID,Voucher_Date,User_ID,Customer_ID,Payment_Status,Order_Code,Status,Delivery_Price,Amount) " .
							"VALUES('$Voucher_ID','$Voucher_Date','$User_ID','$Customer_ID1','$Payment_Status','$Order_Code','$Status','$Delivery_Price','$totalAmount')";
	}else{
		InsertCustomer($conn,$Customer_ID, $Customer_Name, $Customer_Phone, $Customer_Email,$Customer_Address);
		$voucherinsert=	"INSERT INTO `tbl_voucher` " . 
							"(Voucher_ID,Voucher_Date,User_ID,Customer_ID,Payment_Status,Order_Code,Status,Delivery_Price,Amount) " .
							"VALUES('$Voucher_ID','$Voucher_Date','$User_ID','$Customer_ID','$Payment_Status','$Order_Code','$Status','$Delivery_Price','$totalAmount')";
	}
	//"CheckOut" Table "Insert"
	
		
		

	mysqli_query($conn,$voucherinsert);	
	/*******************************************************************/
	$size=count(@$_SESSION['ShoppingCart']);
	
	for ($i=0;$i<$size;$i++)
	{
		$Product_ID=$_SESSION['ShoppingCart'][$i]['Product_ID'];
		$Quantity=$_SESSION['ShoppingCart'][$i]['Quantity'];
		$Supplier_ID=$_SESSION['ShoppingCart'][$i]['Supplier_ID'];
		
				
		@$Discount_Price=$_SESSION['ShoppingCart'][$i]['Discount_Price'];
		
		$sql="SELECT * FROM tbl_product WHERE Product_ID='$Product_ID'";
		$result=mysqli_query($conn,$sql);
		$row=mysqli_fetch_array($result);		
		
		$Selling_Price=$row['Selling_Price'];
		
		/*******************************************************************/
		//"CheckOutDetail" Table "Insert"
		$voucherdetailinsert="INSERT INTO `tbl_voucherdetail` " . 
							"(Voucher_ID,Product_ID,Quantity,Selling_Price,Discount_Price,Supplier_ID) " .
							"VALUES('$Voucher_ID','$Product_ID','$Quantity','$Selling_Price','$Discount_Price','$Supplier_ID')";
		mysqli_query($conn,$voucherdetailinsert);
		/*******************************************************************/
	
	}
	
	$message="Shopping cart is successfully Check Out";
	//Clear "Shopping Cart";
	unset($_SESSION['ShoppingCart']);
					  
}//end of "if"	     
?>
<?php require_once("../template/sidebarfile.php");?>
<!-- Wrapper -->
			<div class="wrapper style1" >
				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major"><h2>Add Customer for CheckOut</h2></header>
							<form method="post" action="ConfirmVoucher" >
                   
                    <?php if($totalAmount==0){echo "There is no product in Voucher";}else{?>
                    <?php
				if (!empty($message))
				{
					if (@$error)
						echo "<div class='error-Message'>$message</div>";
					else
						echo "<div class='success-Message'>$message</div>";
				}
				?>    
                	 <div class="form-group" style="display:none;" >
                        <label for="Voucher_ID">Voucher_ID:</label>
                        <input type="text" class="form-control" id="Voucher_ID" name="Voucher_ID" value="<?php echo  AutoID($conn, 'tbl_voucher','Voucher_ID','V-',6) ?>">
                     </div>
                     <div class="form-group" >
                        <label for="Customer_Name">Customer Name:</label>
                        <input type="text" class="form-control" id="Customer_Name" name="Customer_Name" required>
                     </div>
                     <div class="form-group" >
                         <label for="Customer_Phone">Phone:</label>
                         <input type="text" class="form-control" id="Customer_Phone" name="Customer_Phone" required>
                     </div>
                     <div class="form-group" >
                         <label for="Customer_Email">Email:</label>
                         <input type="email" class="form-control" id="Customer_Email" name="Customer_Email" required>
                     </div>
                     <div class="form-group" >
                         <label for="Customer_Address">Address:</label><br>
                         <textarea name="Customer_Address" id="Customer_Address" rows="5" required></textarea>
                     </div>
                     <div class="form-group" >
                         <label for="Delivery_Price">Delivery:</label>
                         <input type="text" class="form-control" id="Delivery_Price" name="Delivery_Price" required>
                     </div>
                     <div class="form-group">
                          <label for="Payment_Status">Payment Status:</label><br />
                               <select class="form-control" id="Payment_Status" name="Payment_Status"  >
                                  	<option>UMG Office</option>
                                    <option>Pay Bank with AYA</option>
                                    <option>Pay Bank with KBZ</option>
                                    <option>Pay Bank with CB</option>
                                </select>
                      </div>
                      <div class="form-group" >
                             <label for="Status">Order Status:</label><br />
                                  <select class="form-control" id="Status" name="Status" >
                                  	<option >Done</option>
                                    <option>Pending</option>
                                    <option>Deliver</option>
                                 </select>
                      </div>
                      <div class="form-group" >
                             <label for="Order_Code">Order Code from Website:</label>
                             <input type="text" class="form-control" id="Order_Code" name="Order_Code" required>
                       </div>
                       <div class="form-group" >
                             <label for="Voucher_Date">Order Date:</label><br>
                            <input name="Voucher_Date" type="text"  id="Voucher_Date"
                                maxlength="11" value="<?php echo date("d-M-Y")?>" 
                                    onfocus="showCalender(calender,this)"/>
                       </div>
                       <div class="form-group" >
                                  <label for="Total_Amount">Total Amount:</label>
                                  <?php echo $totalAmount; ?>
                       </div>
                         <div class="form-group" >
                                  <input name="submitted" type="submit" value="Save" />
                            <input name="reset" type="reset" value="Clear" />
                            <a href="../Voucher/Add">Continue </a>
                       </div>
                        
                                              
			</form>        
                    
                  <?php } ?>

						</section>
					</div>
				<!-- /Page -->

				
                <div id="copyright"><div class="container"><div class="copyright"><p>Voucher POS System</p></div></div></div>
	</div><!-----End Wrapper-------->

  <!-- REQUIRED JS SCRIPTS -->
<script type="text/javascript">
     $(function(){
   $('#Voucher_Date').datepicker({
      format: 'd-M-yyyy',
	  todayHighlight:true
    });
});
        </script>
      
  <!--  jQuery -->
<script type="text/javascript" src="../js2/jquery-1.11.3.min.js"></script>

<!-- Isolated Version of Bootstrap, not needed if your site already uses Bootstrap -->
<link rel="stylesheet" href="../css2/bootstrap-iso.css" />

<!-- Bootstrap Date-Picker Plugin -->
<script type="text/javascript" src="../js2/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="../css2/bootstrap-datepicker3.css"/>
