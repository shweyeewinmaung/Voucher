<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
include("../library/permissionforEnD.php");
include("../dal/dal_customer.php");


if(isset($_POST['btnDelete']) && isset($_POST['Customer_ID']))
{
	$Customer_ID=Clean($conn,$_POST['Customer_ID']);
	
	
	DeleteCustomer($conn,$Customer_ID);
	print "<script language=\"JavaScript\">window.location.href=\"../../Customer/List \";></script>";
}

if (isset($_GET['Customer_ID']) && $_GET['Customer_ID']!="")
{	
	$Customer_ID=Clean($conn,$_GET['Customer_ID']);
	$ret=GetCustomerDataByCustomerID($conn,$Customer_ID);
	$num=mysqli_num_rows($ret);
}
?>
<?php require_once("../template/sidebarfileforEnD.php");?>

    <!-- Wrapper -->
			<div class="wrapper style1" >
				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major"><h2>Delete Customer</h2></header>
							 <form method="post" >
                       		
                            <?php
                                if($num>0)
                                {
                                        $row=mysqli_fetch_array($ret);
                            ?>
                             
                              <div class="form-group" style="display:none;">
                                  <label for="Customer_ID">ID:</label>&nbsp;&nbsp;&nbsp;
                                 <input type="text" name="Customer_ID" value="<?php echo $row['Customer_ID']; ?>">
                              </div>
                              <div class="form-group">
                                  <label for="Customer_Name">Name:</label>&nbsp;&nbsp;&nbsp;
                                  <?php echo $row['Customer_Name']; ?>
                              </div>
                               <div class="form-group">
                                  <label for="Customer_Phone">Phone:</label>&nbsp;&nbsp;&nbsp;
                                  <?php echo $row['Customer_Phone']; ?>
                              </div>
                              <div class="form-group">
                                  <label for="Customer_Email">Email:</label>&nbsp;&nbsp;&nbsp;
                                  <?php echo $row['Customer_Email']; ?>
                              </div>
                              <div class="form-group">
                                  <label for="Customer_Address">Address:</label>&nbsp;&nbsp;&nbsp;
                                  <?php echo $row['Customer_Address']; ?>
                              </div>
                             <br />                               
                                <button type="submit" class="btn btn-danger" name="btnDelete" style="margin-left:30%; " >Delete</button>
                               <a href="../../Customer/List"> <button  type="button" class="btn btn-default" name="btnDelete" style="margin-left:1%; ">Back</button></a>
                                
                                         
                                    </th>
                                </tr>
                               <?php } ?>
                            </table>
						</form>
						</section>
					</div>
				<!-- /Page -->

				
                <div id="copyright"><div class="container"><div class="copyright"><p>Voucher POS System</p></div></div></div>
	</div><!-----End Wrapper-------->

  