<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
include("../library/permissionforEnD.php");
include("../dal/dal_customer.php");


if(isset($_POST['btnUpdate']) && isset($_POST['Customer_ID']))
{
	$Customer_ID=Clean($conn,$_POST['Customer_ID']);
	$Customer_Name=Clean($conn,$_POST['Customer_Name']);
	$Customer_Phone=Clean($conn,$_POST['Customer_Phone']);
	$Customer_Email=Clean($conn,$_POST['Customer_Email']);
	$Customer_Address=Clean($conn,$_POST['Customer_Address']);
	
	UpdateCustomer($conn,$Customer_ID, $Customer_Name, $Customer_Phone, $Customer_Email,$Customer_Address);
	print "<script language=\"JavaScript\">window.location.href=\"../../Customer/List \";</script>";
}

if (isset($_GET['Customer_ID']) && $_GET['Customer_ID']!="")
{	
	$Customer_ID=Clean($conn,$_GET['Customer_ID']);
	$ret=GetCustomerDataByCustomerID($conn,$Customer_ID);
	$num=mysqli_num_rows($ret);
}
?>
<?php require_once("../template/sidebarfileforEnD.php");?>

<!-- Wrapper -->
			<div class="wrapper style1" >
				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major"><h2>Edit Customer</h2></header>
							<form method="post">
                    		<h1 style="color:#ffffff; margin-left:35%;">Edit Customer</h1>
							<?php
                            if($num>0)
                            {
                                    $row=mysqli_fetch_array($ret);
                        ?>
                        	<div class="form-group" style="display:none;">
                                  <label for="Customer_ID">ID:</label>
                                 <input type="text" name="Customer_ID" value="<?php echo $row['Customer_ID']; ?>">
                              </div>
                            <div class="form-group">
                              <label for="Customer_Name">Name:</label>
                              <input required type="text" class="form-control" id="Customer_Name" name="Customer_Name" value="<?php echo $row['Customer_Name'];  ?>">
                            </div>
                            <div class="form-group">
                              <label for="Customer_Phone">Phone:</label>
                              <input required type="text" class="form-control" id="Customer_Phone" name="Customer_Phone" value="<?php echo $row['Customer_Phone'];  ?>">
                            </div>
                                <div class="form-group">
                              <label for="Customer_Email">Email:</label>
                              <input type="email" class="form-control" id="Customer_Email" name="Customer_Email" value="<?php echo $row['Customer_Email'];  ?>">
                            </div>
                           
                              
                           <div class="form-group">
                              <label for="Customer_Address">Address:</label><br>
                              <textarea name="Customer_Address" rows="5"><?php echo $row['Customer_Address'];  ?></textarea>
                             
                            </div>
                            
                            
                             <?php } ?> 
                           	 <br />
                             <button type="submit" class="btn btn-danger" name="btnUpdate" style="margin-left:30%; " >Edit</button>
                             <a href="../../Customer/List"> <button  type="button" class="btn btn-default" style="margin-left:1%; ">Back</button></a>
                          
                          </form>
						</section>
					</div>
				<!-- /Page -->

				
                <div id="copyright"><div class="container"><div class="copyright"><p>Voucher POS System</p></div></div></div>
	</div><!-----End Wrapper-------->

 