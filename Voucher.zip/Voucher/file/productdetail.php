<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
include("../library/permission.php");
include("../dal/dal_product.php");
include("../dal/dal_category.php");

if (isset($_GET['Product_ID']) && $_GET['Product_ID']!="")
{	
	$Product_ID=Clean($conn,$_GET['Product_ID']);
	$ret=GetProductDataByProductID($conn,$Product_ID);
	$num=mysqli_num_rows($ret);
}


?>
<?php require_once("../template/sidebarfile.php");?>

   <!-- Wrapper -->
			<div class="wrapper style1" >
				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major"><h2>Product Detail</h2></header>
								<div class="table-responsive">
                    <form action="shoppingcart.php" method="get" enctype="multipart/form-data">
                
							<?php
                            if($num>0)
                            {
                                    $row=mysqli_fetch_array($ret);
                        ?>
                    <table id="product_data" class="table table-striped table-bordered dt-responsive nowrap" width="98%" cellspacing="0">
                         <thead>
                            <tr>
                               
                                <th>ID</th>
                                <th>Name</th>
                                <th>SKU Code</th>
                                <th>Category_Name</th>
                                <th>Original Price</th>
                                <th>Selling Price</th>
                                 <th>Discount</th>
                                 <th>Quantity</th>
                                                            
                                <th>ADD</th>
                                
                            </tr>
                            </thead>
                            <tbody>
                             
                            <tr>
                               
                                 <th><input style="display:none;" type="text" readonly id="Product_ID" name="Product_ID"  value="<?php echo $row['Product_ID']; ?>"/><?php echo $row['Product_ID']; ?></th>
                                <th><input style="display:none;" type="text" readonly id="Product_Name" name="Product_Name"  value="<?php echo $row['Product_Name']; ?>"/><?php echo $row['Product_Name']; ?></th>
                                <th><input style="display:none;" type="text" readonly id="Product_Code" name="Product_Code" value="<?php echo $row['Product_Code']; ?>" /><?php echo $row['Product_Code']; ?></th>
                                <th><input style="display:none;" type="text" readonly id="Category_ID" name="Category_ID" value="<?php echo GetCategoryNameByCategoryID($conn,$row['3']); ?>" /><?php echo GetCategoryNameByCategoryID($conn,$row['3']); ?></th>
                                <th><input  style="display:none;"type="text" readonly id="Product_Code" name="Product_Code" value="<?php echo $row['Original_Price']; ?>" /><?php echo $row['Original_Price']; ?></th>
                                <th><input style="display:none;" type="text" readonly id="Product_Code" name="Product_Code" value="<?php echo $row['Selling_Price']; ?>" /><?php echo $row['Selling_Price']; ?></th>
                                 
                               	<th><input type="text"  id="Discount_Price" name="Discount_Price" value="0"/></th> 
                                <th><input type="text"  id="Quantity" name="Quantity" /></th>
                               
                                
                                <!--<th><input type="submit" value="Add to cart" /></th>-->
                                	<th><input type="submit" value="Add to cart" /></th>
                                
                                
                               <!-- <th><a href="../Supplier/Edit/<?php// echo $row['Supplier_ID']; ?>"><img src="../img/wrench-screwdriver.png"  width="20" height="20"/></a></th>
                                <th><a href="../Supplier/Remove/<?php //echo $row['Supplier_ID']; ?>">
                <img src="../img/cross-script.png" width="20" height="20" /></a></th>-->
                            </tr>
                           
                           </tbody>
                     </table>
                       <?php } ?> 
                    </form>    
						</section>
					</div>
				<!-- /Page -->

				
                <div id="copyright"><div class="container"><div class="copyright"><p>Voucher POS System</p></div></div></div>
	</div><!-----End Wrapper-------->