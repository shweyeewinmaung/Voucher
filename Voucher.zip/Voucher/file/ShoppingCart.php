<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
include("../library/permission.php");
include("../dal/dal_product.php");
include("../dal/dal_category.php");

include("../dal/dal_user.php");
include("../dal/shoppingCartFunction.php");

	$shoppingCart = new ShoppingCart();
	
	@$Product_ID=$_GET['Product_ID'];
	@$Discount_Price=$_GET['Discount_Price'];
	@$Quantity=$_GET['Quantity'];
	
	if($Discount_Price=="0"){$statusOK=$shoppingCart->Insert($Product_ID, $Quantity);}
	else{$statusOK=$shoppingCart->Insert1($Product_ID,$Discount_Price, $Quantity);}
	

		
	if(@$_GET['Action']=="Remove")
	{
		$Product_ID=$_GET['Product_ID'];
		$shoppingCart->Remove($Product_ID);
	}
	else if (@$_GET['Action']=="Clear")
	{
		//Function Call to Clear "ShoppingCart"
		$shoppingCart->Clear();
	}
	?>
<?php require_once("../template/sidebarfile.php");?>
<!-- Wrapper -->
			<div class="wrapper style1" >
				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major"><h2>Shopping Cart</h2></header>
							<div class="table-responsive">
                    <form method="get">
                 <table align="center" class="shoppingCart">                
				<?php
					$size=count(@$_SESSION['ShoppingCart']);
					
					$totalAmount=0;
					
					if ($size==0)
					{
				?>
                	<td style="width:600px;text-align:center;">
						<h3>Your Shopping Cart is empty.</h3>
                    </td>
                    <?php
					}//end of "if"


					for($i=0;$i<$size;$i++)
					{			
						$Product_ID=$_SESSION['ShoppingCart'][$i]['Product_ID'];
						@$Discount_Price=$_SESSION['ShoppingCart'][$i]['Discount_Price'];
						$Quantity=$_SESSION['ShoppingCart'][$i]['Quantity'];								
						if($Discount_Price==0)
						{
							$sql="SELECT * FROM tbl_product WHERE Product_ID='$Product_ID'";	
						
							$result=mysqli_query($conn,$sql);
							$row=mysqli_fetch_array($result);
							
							$amount= $Quantity * $row['Selling_Price'];
							$totalAmount+=$amount;
							
							if ($i%2==0)
								echo "<tr>";
							else
								echo "<tr class='alt'>";
						}
						else
						{
							$sql="SELECT * FROM tbl_product WHERE Product_ID='$Product_ID'";	
						
							$result=mysqli_query($conn,$sql);
							$row=mysqli_fetch_array($result);
							
							$amount= $Quantity * $Discount_Price;
							$totalAmount+=$amount;
							
							if ($i%2==0)
								echo "<tr>";
							else
								echo "<tr class='alt'>";
						}
						
                ?>
                    <td>                        
                        <table class="sub-shoppingCart">
                            <tr>
                                
                                <td style="vertical-align:top;text-align:left;padding:0 5 0 10;">
                                    <p>
                                      ID: <strong><?php echo $row['Product_ID']; ?></strong><br/>
                                      Name: <strong><?php echo $row['Product_Name']; ?></strong><br/>
                                      Category: <strong><?php echo GetCategoryNameByCategoryID($conn,$row['3']); ?></strong><br/>
                                      Code: <strong><?php echo $row['Product_Code']; ?></strong><br/>  
                                      Price: <strong><?php echo $row['Selling_Price']; ?></strong><br/>                                   
                                      Discount: <strong><?php if($Discount_Price==""){echo "0";}else{echo $Discount_Price;} ?></strong><br/>                                
                                     Quantity : <strong><?php echo $Quantity; ?></strong><br/>      
                                                                                                                                                   
                                     Amount : <strong><?php echo $amount; ?></strong><br/>
                                      <a href="ShoppingCart.php?Product_ID=<?php echo $Product_ID; ?>&Action=Remove">Remove</a>
                                    </p>
                                </td>
                            </tr>    
                        </table>
                    </td>
                  </tr>
            <?php             
                    }
            ?>
            	<tr>
                	<td colspan="2" style="text-align:right;padding:3px;">
	                    
                    	<a href="ShoppingCart.php?Action=Clear">Clear</a>&nbsp;
                    	<strong>Total Amount : <?php echo $totalAmount; ?></strong>
                    </td>
                </tr>
            </table>
            </form> 
						</section>
					</div>
				<!-- /Page -->

				
                <div id="copyright"><div class="container"><div class="copyright"><p>Voucher POS System</p></div></div></div>
	</div><!-----End Wrapper-------->


  <!-- REQUIRED JS SCRIPTS -->
<link rel="stylesheet" href="../css3/bootstrap.min.css">
<link rel="stylesheet" href="../css3/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="../css3/responsive.bootstrap.min.css">
<script src="../js3/jquery-1.12.4.js"></script>  
<script src="../js3/jquery.dataTables.min.js"></script>  
<script src="../js3/dataTables.bootstrap.min.js"></script> 
<script src="../js3/dataTables.responsive.min.js"></script>  
<script src="../js3/responsive.bootstrap.min.js"></script> 
<script>
    $(document).ready(function() {
    $('#product_data').DataTable();
} );
    </script>
  <style>
  #product_data_wrapper{
	  width:50%;
  }
  #product_data_filter{
	 margin-right:10%;
  }
  
  div.dataTables_wrapper div.dataTables_paginate {
	  text-align:left;
  }
  </style>