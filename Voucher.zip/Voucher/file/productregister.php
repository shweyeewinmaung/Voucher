<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
include("../library/permission.php");
include("../dal/dal_category.php");
include("../dal/dal_product.php");

if (isset($_POST['Product_Name']))
{	
	$Product_ID=AutoID($conn, 'tbl_product','Product_ID','P-',6);
	$Product_Name=Clean($conn,$_POST['Product_Name']);
	$Product_Code=Clean($conn,$_POST['Product_Code']);
	
	$Category_ID=Clean($conn,$_POST['Category_ID']);
	$Original_Price=Clean($conn,$_POST['Original_Price']);
	$Selling_Price=Clean($conn,$_POST['Selling_Price']);
	
	$num=mysqli_num_rows(GetProductDataBy_ProductName($conn,$Product_Name));
	
	if($num>0)
	{
		$_SESSION['Product_Name']="Exist";
	}else{
		InsertProduct($conn,$Product_ID, $Product_Name,$Product_Code,$Category_ID,$Original_Price,$Selling_Price);
		$_SESSION['Product_Name']="Success";
	}
}


?>
<?php require_once("../template/sidebarfile.php");?>

   <!-- Wrapper -->
			<div class="wrapper style1" >
				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major"><h2>Add Product</h2></header>
								<form method="post">
                    		
                           <font style="color:red; font-size:18px; line-height:50px;">
							<?php
                                if(@$_SESSION['Product_Name']=="Success"){ echo "Name is Added"; unset($_SESSION['Product_Name']);}
                             ?>
                            <?php 
                                if(@$_SESSION['Product_Name']=="Exist"){ echo "Already Exist!"; unset($_SESSION['Product_Name']);}
                            ?></font>
                            <div class="form-group">
                              <label for="Product_Name">Name:</label>
                              <input type="text" class="form-control" id="Product_Name" name="Product_Name" required>
                            </div>
                             <div class="form-group">
                              <label for="Product_Code">Code:</label>
                              <input type="text" class="form-control" id="Product_Code" name="Product_Code" required>
                            </div>
                            
                             <div class="form-group" style="padding: 5px 5px 5px 5px;">
                            <label for="Category_Name">Category:</label><br />
                              <select class="form-control" id="Category_ID" name="Category_ID" >
                              <option></option>
                              
                              <?php 
										  $retCategory=GetCategoryDataByCategory($conn);
											$numCategory=mysqli_num_rows($retCategory);
										while($rowCategory=mysqli_fetch_array($retCategory))
                                            {
                                                echo "<option value=".$rowCategory['Category_ID'].">" . $rowCategory['Category_Name'] . "</option>";
                                            }
                                ?>
                               
                               </select>
                            </div>
                             <div class="form-group">
                              <label for="Original_Price">Buying Price:</label>
                              <input type="text" class="form-control" id="Original_Price" name="Original_Price" required>
                            </div>
                              <div class="form-group">
                              <label for="Selling_Price">Selling Price:</label>
                              <input type="text" class="form-control" id="Selling_Price" name="Selling_Price" required>
                            </div>
                           <button type="submit" class="btn btn-default" name="btnAdd" >Entry</button>
                          
                          </form>
						</section>
					</div>
				<!-- /Page -->

				
                <div id="copyright"><div class="container"><div class="copyright"><p>Voucher POS System</p></div></div></div>
	</div><!-----End Wrapper-------->