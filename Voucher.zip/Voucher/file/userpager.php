<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
//include("../library/permission.php");
include("../dal/dal_user.php");
include("../pager/pager_user.php");

$pageSize=1;


if(isset($_GET['page']))
{
	$currentPageIndex=Clean($conn,$_GET['page']);
}
else
{
	$currentPageIndex=1;
}
$objPager=new pager($pageSize,$currentPageIndex);




if(isset($_GET['btnSearch']) )
{
	$User_Name=Clean($conn,$_GET['User_Name']);
	$User_Role=Clean($conn,$_GET['User_Role']);
	
	$sql=$objPager->SearchData_UserSearch($conn,$_GET['User_Name'], $_GET['User_Role']);
	$ret=$objPager->Search_Data($conn,$sql);
	$num=mysqli_num_rows($ret);
}
if(!isset($_GET['btnSearch']) )
{
	@$User_Name=Clean($conn,$_GET['User_Name']);
	@$User_Role=Clean($conn,$_GET['User_Role']);
		
	
	$sql=$objPager->SearchData_GetAllUser($conn);
	$ret=$objPager->Search_Data($conn,$sql);
	$num=mysqli_num_rows($ret);
}

?>
<?php require_once("../template/sidebarfile.php");?>

    <!-- Wrapper -->
			<div class="wrapper style1" >
				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major"><h2>User List Pager</h2></header>
							<div class="table-responsive">
                    <form method="get" class="formsearch">
                   		<table cellspacing="3">
                            <tr>
                                <th>Search For User : </th>
                                <th><input type="text" class="form-control" name="User_Name" placeholder="Name" style="margin-left:2%;" ></th>
                                <th><input type="text" class="form-control"  name="User_Role" placeholder="Role"style="margin-left:3%;"></th>
                                <th><button type="submit" class="btn btn-info"  name="btnSearch" style="margin-left:10%;">Search</button></th>
                                <th><button id="Reset" class="btn btn-info"  style="margin-left:10%;">Show All</button></th>
                            </tr>
                        </table>
                     </form>
                      
                     <table id="user_data" class="table table-striped table-bordered">  
                        <?php
					if($num>0)
					{
						?>
                         <thead>
                <tr>
                    <th>No</th>
                    <th>Name</th>
                    <th>Role</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Created Date</th>
                    <th>Lastin Update</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
                </thead>
                <tbody>
                 <?php 
				 	
				 	$u=(($currentPageIndex*$pageSize)+1)-$pageSize;
				  	while($row=mysqli_fetch_array($ret)){	?>  
                <tr>
                    <th><?php echo $u; ?></th>
                    <th><?php echo $row['User_Name']; ?></th>
                    <th><?php echo $row['User_Role']; ?></th>
                    <th><?php echo $row['User_Email']; ?></th>
                    <th><?php echo $row['User_Password']; ?></th>
                    <th><?php echo $row['Created_Date']; ?></th>
                    <th><?php echo $row['Lastin_Date']; ?></th>
                    <th><a href="../User/Edit/<?php echo $row['User_ID']; ?>"><img src="../img/wrench-screwdriver.png"  width="20" height="20"/></a></th>
                    <th><a href="../User/Remove/<?php echo $row['User_ID']; ?>">
    <img src="../img/cross-script.png" width="20" height="20" /></a></th>
                </tr>
               <?php $u=$u+1;  } 
			   
			   }
					 else
					{
						?>
                        	<center>Not available!</center>
                        <?php
					}
			   ?> 
                     </table>
                    
                </div>  

 		<span id="pager"> 
                       <?php
                	@$objPager->Generate_Pager($str,$conn);
                ?>
                </span>
						</section>
					</div>
				<!-- /Page -->

				
                <div id="copyright"><div class="container"><div class="copyright"><p>Voucher POS System</p></div></div></div>
	</div><!-----End Wrapper-------->


 <script src="../js1/jquery.min.js"></script>  
    <script src="../js1/jquery.dataTables.min.js"></script>  
    <script src="../js1/dataTables.bootstrap.min.js"></script>            
    
    <script src="../js/custom.js"></script>
   	 
 
   
  <style>
  #user_data_wrapper{
	  width:98%;
  }
  #user_data_filter{
	  float:right;
  }
 
 

  </style>