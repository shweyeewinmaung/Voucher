<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
include("../library/permission.php");
include("../dal/dal_product.php");
include("../dal/dal_category.php");
include("../dal/dal_user.php");
include("../dal/dal_customer.php");
include("../dal/dal_supplier.php");


$ret=GetVoucherDataByVoucher($conn);
$num=mysqli_num_rows($ret);
?>
<?php require_once("../template/sidebarfile.php");?>

   <!-- Wrapper -->
			<div class="wrapper style1" >
				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major"><h2>Voucher List</h2></header>
							 <form  method="get" enctype="multipart/form-data">
                    <table id="voucher_all_data" class="table table-striped table-bordered dt-responsive nowrap"  cellspacing="0">
                         <thead>
                            <tr>
                                <th>No</th>
                               
                                <th>ID</th>
                                <th>Date</th>
                                <th>User</th>
                                <th>Customer</th>
                                <th>Payment Status</th>
                                 <th>Order Code</th>
                                <th>Status</th>
                                <th>Delivery Price</th>
                                <th>Total Amount</th>
                                                            
                                <th>Edit</th>
                                <th>Delete</th>
                                <th>Voucher Detail</th>
                                
                            </tr>
                            </thead>
                            <tbody>
                             <?php  $u=1;
                                while($row=mysqli_fetch_array($ret)){	?>  
                            <tr>
                                <th><?php echo $u; ?></th>
                               
                                <th><?php echo $row['Voucher_ID']; ?></th>
                                <th><?php echo $row['Voucher_Date']; ?></th>
                                <th><?php echo GetUserNameByUserID($conn,$row['2']); ?></th>
                                <th><?php echo GetCustomerNameByCustomerID($conn,$row['3']); ?></th>
                                <th><?php echo $row['Payment_Status']; ?></th>
                                <th><?php echo $row['Order_Code']; ?></th>
                                <th><?php echo $row['Status']; ?></th>
                                <th><?php echo $row['Delivery_Price']; ?></th>
                                <th><?php echo $row['Amount']; ?></th>
                                
                                <th><a href="../Voucher/Edit/<?php echo $row['Voucher_ID']; ?>"><img src="../img/wrench-screwdriver.png"  width="20" height="20"/></a></th>
                                <th><a href="../Voucher/Remove/<?php echo $row['Voucher_ID']; ?>">
                <img src="../img/cross-script.png" width="20" height="20" /></a></th>
                                
                            	<th>
                                <?php 
											$y=1;
											$ret1=GetVoucherDataByVoucherID($conn,$row['Voucher_ID']);
											$num1=mysqli_num_rows($ret1);
											while($row1=mysqli_fetch_array($ret1))
											{
												
												$ret2=GetProductDataByProductID($conn,$row1['Product_ID']);
												$num2=mysqli_num_rows($ret2);
												$row2=mysqli_fetch_array($ret2);
												
												$ret3=GetCategoryDataByCategoryID($conn,$row2['Category_ID']);
												$num3=mysqli_num_rows($ret3);
												$row3=mysqli_fetch_array($ret3);
												
												$ret5=GetSupplierDataBySupplierID($conn,$row1['Supplier_ID']);
												$num5=mysqli_num_rows($ret5);
												$row5=mysqli_fetch_array($ret5);
									  
									  ?> 
                                	  <p style=" border-bottom:2px dotted#C00;background:#ccc;"> 
                                     <font style="color:#300; font-weight:bold;"> No : <?php echo $y;?></font><br>
                                    Product Name : <font style="color:#300; font-weight:bold;"><?php echo $row2['Product_Name'];  ?></font><br>
                                	Category Name : <font style="color:#300; font-weight:bold;"><?php echo $row3['Category_Name']; ?></font><br>
                                    Supplier : <font style="color:#300; font-weight:bold;"><?php echo $row5['Supplier_Name']; ?></font><br>
                                    Quantity : <font style="color:#300; font-weight:bold;"><?php echo $row1['Quantity']; ?></font><br>
                                    Selling Price : <font style="color:#300; font-weight:bold;"><?php echo $row1['Selling_Price']; ?></font><br>
                                    Discount : <font style="color:#300; font-weight:bold;"><?php if($row1['Discount_Price']==0){echo "0";}else{echo $row1['Discount_Price']; }  ?> </font><br>
                                    Amount : <font style="color:#300; font-weight:bold;"><?php if($row1['Discount_Price']==0){echo $row1['Quantity']*$row1['Selling_Price'];}else{echo $row1['Quantity']*$row1['Discount_Price']; }?></font><br><br>
                                    
                                     </p>
                                <?php  $y=$y+1;} ?>
                                 <font style="color:#600; font-weight:bold;">Total Amount: <?php echo $row['Amount']; ?></font><br>
                                 <font style="color:#600; font-weight:bold;">Delivery Price :<?php echo $row['Delivery_Price']; ?></font><br> <br><p style="border-bottom:2px  dashed#333"></p>
                                
                                </th>
                            </tr>
                           <?php $u=$u+1;  } ?> 
                           </tbody>
                     </table>
                    </form> 
                    </div> <!-----------table responsive End ------>   
						</section>
					</div>
				<!-- /Page -->

				
                <div id="copyright"><div class="container"><div class="copyright"><p>Voucher POS System</p></div></div></div>
	</div><!-----End Wrapper-------->


  <!-- REQUIRED JS SCRIPTS -->
<link rel="stylesheet" href="../css3/bootstrap.min.css">
<link rel="stylesheet" href="../css3/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="../css3/responsive.bootstrap.min.css">
<script src="../js3/jquery-1.12.4.js"></script>  
<script src="../js3/jquery.dataTables.min.js"></script>  
<script src="../js3/dataTables.bootstrap.min.js"></script> 
<script src="../js3/dataTables.responsive.min.js"></script>  
<script src="../js3/responsive.bootstrap.min.js"></script> 
<script>
    $(document).ready(function() {
    $('#voucher_all_data').DataTable();
} );
    </script>
  <style>
  #voucher_all_data_wrapper{
	  width:98%;
  }
  #voucher_all_data_filter{
	 margin-right:10%;
  }
  
  div.dataTables_wrapper div.dataTables_paginate {
	  text-align:left;
  }
  </style>