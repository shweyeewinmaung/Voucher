<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
include("../library/permission.php");
include("../dal/dal_product.php");
include("../dal/dal_category.php");

$ret=GetProductDataByProduct($conn);
$num=mysqli_num_rows($ret);
?>
<?php require_once("../template/sidebarfile.php");?>

    <!-- Wrapper -->
			<div class="wrapper style1" >
				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major"><h2>Product List</h2></header>
								<div class="table-responsive">
                    <form  method="get" enctype="multipart/form-data">
                    <table id="product_all_data" class="table table-striped table-bordered dt-responsive nowrap"  cellspacing="0">
                         <thead>
                            <tr>
                                <th>No</th>
                               
                                <th>Name</th>
                                <th>SKU Code</th>
                                <th>Category Name</th>
                                <th>Original Price</th>
                                <th>Selling Price</th>
                                                            
                                <th>Edit</th>
                                <th>Delete</th>
                                
                            </tr>
                            </thead>
                            <tbody>
                             <?php  $u=1;
                                while($row=mysqli_fetch_array($ret)){	?>  
                            <tr>
                                <th><?php echo $u; ?></th>
                               
                                <th><?php echo $row['Product_Name']; ?></th>
                                <th><?php echo $row['Product_Code']; ?></th>
                                <th><?php echo GetCategoryNameByCategoryID($conn,$row['3']); ?></th>
                                <th><?php echo $row['Original_Price']; ?></th>
                                <th><?php echo $row['Selling_Price']; ?></th>
                                
                                <th><a href="../Product/Edit/<?php echo $row['Product_ID']; ?>"><img src="../img/wrench-screwdriver.png"  width="20" height="20"/></a></th>
                                <th><a href="../Product/Remove/<?php echo $row['Product_ID']; ?>">
                <img src="../img/cross-script.png" width="20" height="20" /></a></th>
                                
                            
                            </tr>
                           <?php $u=$u+1;  } ?> 
                           </tbody>
                     </table>
                    </form> 
                    </div> <!-----------table responsive End ------>   

						</section>
					</div>
				<!-- /Page -->

				
                <div id="copyright"><div class="container"><div class="copyright"><p>Voucher POS System</p></div></div></div>
	</div><!-----End Wrapper-------->

  <!-- REQUIRED JS SCRIPTS -->
<link rel="stylesheet" href="../css3/bootstrap.min.css">
<link rel="stylesheet" href="../css3/dataTables.bootstrap.min.css">
<link rel="stylesheet" href="../css3/responsive.bootstrap.min.css">
<script src="../js3/jquery-1.12.4.js"></script>  
<script src="../js3/jquery.dataTables.min.js"></script>  
<script src="../js3/dataTables.bootstrap.min.js"></script> 
<script src="../js3/dataTables.responsive.min.js"></script>  
<script src="../js3/responsive.bootstrap.min.js"></script> 
<script>
    $(document).ready(function() {
    $('#product_all_data').DataTable();
} );
    </script>
  <style>
  #product_all_data_wrapper{
	  width:98%;
  }
  #product_all_data_filter{
	 margin-right:10%;
  }
  
  div.dataTables_wrapper div.dataTables_paginate {
	  text-align:left;
  }
  </style>