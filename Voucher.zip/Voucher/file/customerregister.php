<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
include("../library/permission.php");
include("../dal/dal_customer.php");

if (isset($_POST['Customer_Name']))
{	
	$Customer_ID=AutoID($conn, 'tbl_customer','Customer_ID','C-',6);
	$Customer_Name=Clean($conn,$_POST['Customer_Name']);
	$Customer_Phone=Clean($conn,$_POST['Customer_Phone']);
	$Customer_Email=Clean($conn,$_POST['Customer_Email']);
	$Customer_Address=Clean($conn,$_POST['Customer_Address']);
	
	$ret=GetCustomerDataBy_CustomerName($conn,$Customer_Name);
		
	$num=mysqli_num_rows($ret);
	if($num>0)
	{
		$_SESSION['Customer_Name']="Exist";
	}else{
		InsertCustomer($conn,$Customer_ID, $Customer_Name, $Customer_Phone, $Customer_Email,$Customer_Address);
		$_SESSION['Customer_Name']="Success";
	}
}
?>
<?php require_once("../template/sidebarfile.php");?>

     <!-- Wrapper -->
			<div class="wrapper style1" >
				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major"><h2>Add Customer</h2></header>
							<form method="post">
                    		
                           <font style="color:red; font-size:18px; line-height:50px;">
							<?php
                                if(@$_SESSION['Customer_Name']=="Success"){ echo "Name is Added"; unset($_SESSION['Customer_Name']);}
                             ?>
                            <?php 
                                if(@$_SESSION['Customer_Name']=="Exist"){ echo "Already Exist!"; unset($_SESSION['Customer_Name']);}
                            ?></font>
                            <div class="form-group">
                              <label for="Customer_Name">Name:</label>
                              <input type="text" class="form-control" id="Customer_Name" name="Customer_Name" required>
                            </div>
                            <div class="form-group">
                              <label for="Customer_Phone">Phone:</label>
                              <input type="text" class="form-control" id="Customer_Phone" name="Customer_Phone" required>
                            </div>
                           <div class="form-group">
                              <label for="Customer_Email">Email:</label>
                              <input type="email" class="form-control" id="Customer_Email" name="Customer_Email">
                            </div>
                           <div class="form-group">
                              <label for="Customer_Address">Address:</label><br>
                              <textarea name="Customer_Address" rows="5"></textarea>
                             
                            </div>
                           	<br />                            
                            <button type="submit" class="btn btn-default" name="btnAdd" style="margin-left:30%; " >Entry</button>
                          
                          </form>
						</section>
					</div>
				<!-- /Page -->

				
                <div id="copyright"><div class="container"><div class="copyright"><p>Voucher POS System</p></div></div></div>
	</div><!-----End Wrapper-------->
