<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
include("../library/permissionforEnD.php");
include("../dal/dal_product.php");
include("../dal/dal_category.php");
include("../dal/dal_voucher.php");
include("../dal/dal_user.php");
include("../dal/dal_customer.php");


if(isset($_POST['btnDelete']) && isset($_POST['Voucher_ID']))
{
	$Voucher_ID=Clean($conn,$_POST['Voucher_ID']);
	
	DeleteVoucher($conn,$Voucher_ID);
	print "<script language=\"JavaScript\">window.location.href=\"../../Voucher/List \";</script>";
}

if (isset($_GET['Voucher_ID']) && $_GET['Voucher_ID']!="")
{	
	$Voucher_ID=Clean($conn,$_GET['Voucher_ID']);
	$ret=GetVoucherByVoucherID($conn,$Voucher_ID);
	$num=mysqli_num_rows($ret);
}
?>
<?php require_once("../template/sidebarfileforEnD.php");?>

<!-- Wrapper -->
			<div class="wrapper style1" >
				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major"><h2>Delete Voucher</h2></header>
							<form method="post">
                    		
                            <?php
                            if($num>0)
                            {
                                    $row=mysqli_fetch_array($ret);
                        ?>
                        	<div class="form-group" style="display:none;">
                                  <label for="Voucher_ID">ID:</label>
                                 <input type="text" name="Voucher_ID" value="<?php echo $row['Voucher_ID']; ?>">
                              </div>
                            <div class="form-group" >
                             <label for="Voucher_Date">Order Date:</label>
                           		<?php echo $row['Voucher_Date'];?>
                       		</div>
                             <div class="form-group">
                              <label for="User_ID">Admin:</label>
                              <?php echo GetUserNameByUserID($conn,$row['2']); ?>
                            </div>
                             <div class="form-group">
                              <label for="Customer_Name">Customer Name:</label>
                                <?php echo GetCustomerNameByCustomerID($conn,$row['3']); ?>
                            </div>
                            <div class="form-group">
                            <?php
								$ret1=GetCustomerDataByCustomerID($conn,$row['Customer_ID']);
								$num1=mysqli_num_rows($ret1);
								while($row1=mysqli_fetch_array($ret1))
								{
									?>
                                  <p style="line-height:30px; font-weight:bold; color:#600; ">  Phone : <?php echo $row1['Customer_Phone']; ?><br>
                                    Email : <?php echo $row1['Customer_Email']; ?><br>
                                    Address : <?php echo $row1['Customer_Address'];?><br></p>
                             <?php 
								}
							?>
                            </div>
                             <div class="form-group">
                                <label for="Product_ID">All Product In a Voucher:</label>
                            <?php
								$ret2=GetVoucherDataByVoucherID($conn,$row['Voucher_ID']);
								$num2=mysqli_num_rows($ret2);
								while($row2=mysqli_fetch_array($ret2))
								{
									$ret3=GetProductDataByProductID($conn,$row2['Product_ID']);
									$num3=mysqli_num_rows($ret3);
									$row3=mysqli_fetch_array($ret3);
									
									$ret4=GetCategoryDataByCategoryID($conn,$row3['Category_ID']);
									$num4=mysqli_num_rows($ret4);
									$row4=mysqli_fetch_array($ret4);
									?>
                               
                              
                              <p style="line-height:30px; font-weight:bold; color:#600; ">  Product Name : <?php echo $row3['Product_Name']; ?><br>
                                    SKU Code : <?php echo $row3['Product_Code']; ?><br>
                                    Category : <?php echo $row4['Category_Name']; ?><br>
                                    Original Price : <?php echo $row3['Original_Price']; ?><br>
                                    Selling Price : <?php echo $row3['Selling_Price']; ?><br>
                                    Discount Price : <?php echo $row2['Discount_Price']; ?><br>
                                    Amount : <?php if($row2['Discount_Price']==0){echo $row2['Quantity']*$row2['Selling_Price'];}else{echo $row2['Quantity']*$row2['Discount_Price']; }?><br><br>
                                    
                               </p>
                               
                             <?php 
								}
							?>
                           
                               </div>                       
                             <div class="form-group">
                              <label for="Amount">Total Amount:</label>
                              <?php echo $row['Amount']; ?>
                            </div>
                            <div class="form-group">
                          <label for="Payment_Status">Payment Status:</label>
                               <?php echo $row['Payment_Status']; ?>
                              
                      		</div>
                             <div class="form-group">
                              <label for="Order_Code">Order Code From Website:</label>
                              <?php echo $row['Order_Code']; ?>
                            </div>
                             <div class="form-group" >
                             <label for="Status">Order Status:</label>
                                  <?php echo $row['Status']; ?>
                             </div>
                      		 <div class="form-group">
                              <label for="Delivery_Price">Delivery Price:</label>
                             <?php echo $row['Delivery_Price']; ?>
                            </div>
                           <?php } ?> 
                           	<br />
                             <button type="submit" class="btn btn-danger" name="btnDelete" style="margin-left:30%; " >Delete</button>
                             <a href="../../Voucher/List"> <button  type="button" class="btn btn-default" style="margin-left:1%; ">Back</button></a>

                          </form>
						</section>
					</div>
				<!-- /Page -->

				
                <div id="copyright"><div class="container"><div class="copyright"><p>Voucher POS System</p></div></div></div>
	</div><!-----End Wrapper-------->
