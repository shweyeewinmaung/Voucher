<?php
session_start();

include("../library/db.php");
include("../library/function.php");
include("../library/globalfunction.php");
include("../library/permissionforEnD.php");
include("../dal/dal_user.php");


if(isset($_POST['btnDelete']) && isset($_POST['User_ID']))
{
	$User_ID=Clean($conn,$_POST['User_ID']);
	
	
	DeleteUser($conn,$User_ID);
	print "<script language=\"JavaScript\">window.location.href=\"../../User/List \";</script>";
}

if (isset($_GET['User_ID']) && $_GET['User_ID']!="")
{	
	$User_ID=Clean($conn,$_GET['User_ID']);
	$ret=GetUserDataByUserID($conn,$User_ID);
	$num=mysqli_num_rows($ret);
}
?>
<?php require_once("../template/sidebarfileforEnD.php");?>

    <!-- Wrapper -->
			<div class="wrapper style1" >
				<!-- Page -->
					<div id="page" class="container">
						<section>
							<header class="major"><h2>Delete User</h2></header>
							<form method="post" >
                       		
                            <?php
                                if($num>0)
                                {
                                        $row=mysqli_fetch_array($ret);
                            ?>
                             
                              <div class="form-group" style="display:none;">
                                  <label for="User_ID">ID:</label>
                                 <input type="text" name="User_ID" value="<?php echo $row['User_ID']; ?>">
                              </div>
                              <div class="form-group">
                                  <label for="User_Name">Name:</label>
                                  <?php echo $row['User_Name']; ?>
                              </div>
                               <div class="form-group">
                                  <label for="User_Role">Type:</label>
                                  <?php echo $row['User_Role']; ?>
                              </div>
                              <div class="form-group">
                                  <label for="User_Email">Email:</label>
                                  <?php echo $row['User_Email']; ?>
                              </div>
                              <div class="form-group">
                                  <label for="User_Password">Password:</label>
                                  <?php echo $row['User_Password']; ?>
                              </div>
                             	<br />                               
                                <button type="submit" class="btn btn-danger" name="btnDelete" style="margin-left:30%; " >Delete</button>
                               <a href="../../User/List"> <button  type="button" class="btn btn-default" name="btnDelete" style="margin-left:1%; ">Back</button></a>
                                
                                         
                                    </th>
                                </tr>
                               <?php } ?>
                            </table>
	</form>
						</section>
					</div>
				<!-- /Page -->

				
                <div id="copyright"><div class="container"><div class="copyright"><p>Voucher POS System</p></div></div></div>
	</div><!-----End Wrapper-------->

  