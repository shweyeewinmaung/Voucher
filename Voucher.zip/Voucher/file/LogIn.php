<?php
session_start();

?>
<head>
		<title>Voucher POS</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery.dropotron.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-wide.css" />
			 <style>#skel-layers-inactiveWrapper{ height:0%!important;}</style>
	</head>
  <body style="background-image:url(img/background.jpg); background-size:cover;">
  
  
  
  <!-- Wrapper -->
			<div class="wrapper style1" >
				<!-- Page -->
					
						<div class="container" style="padding-top: 20px; ">
             	<form method="post" action="file/loginval.php" style=" padding-bottom:20px; ">
                <img src="img/logo.png" alt="" style="background-size:cover; " class="img-responsive"><br><br>
                    		<?php
				if(isset($_SESSION['LogIn']) && $_SESSION['LogIn']="Fail")
				{
					?>
                    
	                  <b style="color:red; font-weight:bold;">Invalid LogIn! Please Try Again!!!</b><br>
                    <?php
				}
			?>
                              <label for="User_Name" style="color:#ffffff;">Name:</label>
                              <input type="text" class="form-control" id="User_Name" name="User_Name">
                         
                           
                              <label for="User_Password" style="color:#ffffff;">Password:</label>
                              <input type="password" class="form-control" id="User_Password" name="User_Password"><br><br>
                           
                                                         
                            <button type="submit" class="btn btn-default1" name="btnAdd"  style="margin-left:30%;">Log In</button>
                          
                          </form>
                </div><!------contaioner----->
								
             
	</div><!-----End Wrapper-------->

  
</body>
  