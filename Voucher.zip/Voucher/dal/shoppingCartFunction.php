<?php
	class ShoppingCart
{
	//Constructor
	public function _construct()
	{
		if (!isset($_SESSION['ShoppingCart']))
		{
			//Creating Session "Array"
			$_SESSION['ShoppingCart']=array();	
		}
	}

	//Function to "Total Amount"
	function Get_TotalAmount()
	{
		$size=count($_SESSION['ShoppingCart']);					
		$totalAmount=0;
	
		for($i=0;$i<$size;$i++)
		{			
			$ItemID=$_SESSION['ShoppingCart'][$i]['Product_ID'];
			$Quantity=$_SESSION['ShoppingCart'][$i]['Quantity'];								
			
			$sql="SELECT * FROM tbl_product WHERE Product_ID='$Product_ID'";	
			$result=mysqli_query($conn,$sql);
			$row=mysqli_fetch_array($result);
			
			$amount= $Quantity * $row['Selling_Price'];
			$totalAmount+=$amount;
		}
		return $totalAmount;
	}
	
	function Insert($Product_ID,$Quantity,$Supplier_ID)
	{												
		//Function Call to check
		//If the "Item" already existed in "Session"
		$index=$this->IndexOf($Product_ID);
		
		//index=1 means "Item" is not existed in "Session"
		if ($index==-1)
		{
			//Get "ShoppingCart" session array size
			$size=count(@$_SESSION['ShoppingCart']);
			
			$_SESSION['ShoppingCart'][$size]['Product_ID']=$Product_ID;
			$_SESSION['ShoppingCart'][$size]['Quantity']=$Quantity;
			$_SESSION['ShoppingCart'][$size]['Supplier_ID']=$Supplier_ID;
		}
		else
		{
			//$_SESSION['ShoppingCart']=array();
			$_SESSION['ShoppingCart'][$index]['Product_ID']=$Product_ID;
			$_SESSION['ShoppingCart'][$index]['Quantity']=$Quantity;
			$_SESSION['ShoppingCart'][$index]['Supplier_ID']=$Supplier_ID;
		}								
	}
	function Insert1($Product_ID,$Discount_Price,$Quantity,$Supplier_ID)
	{												
		//Function Call to check
		//If the "Item" already existed in "Session"
		$index=$this->IndexOf($Product_ID);
		
		//index=1 means "Item" is not existed in "Session"
		if ($index==-1)
		{
			//Get "ShoppingCart" session array size
			$size=count(@$_SESSION['ShoppingCart']);
			
			$_SESSION['ShoppingCart'][$size]['Product_ID']=$Product_ID;
			$_SESSION['ShoppingCart'][$size]['Discount_Price']=$Discount_Price;
			$_SESSION['ShoppingCart'][$size]['Quantity']=$Quantity;
			$_SESSION['ShoppingCart'][$size]['Supplier_ID']=$Supplier_ID;
		}
		else
		{
			//$_SESSION['ShoppingCart']=array();
			$_SESSION['ShoppingCart'][$index]['Product_ID']=$Product_ID;
			$_SESSION['ShoppingCart'][$index]['Discount_Price']=$Discount_Price;
			$_SESSION['ShoppingCart'][$index]['Quantity']=$Quantity;
			$_SESSION['ShoppingCart'][$index]['Supplier_ID']=$Supplier_ID;
		}								
	}		
	
		
	function Remove($Product_ID)
	{
		$index=$this->IndexOf($Product_ID);
		
		 "Product_ID: $Product_ID " . " Index : $index";
		
		if ($index>-1)
		{
			unset($_SESSION['ShoppingCart'][$index]);
		}
		
		@$_SESSION['ShoppingCart']=array_values($_SESSION['ShoppingCart']);
	}
	
	function Clear()
	{
		unset($_SESSION['ShoppingCart']);
	}
	
	function IndexOf($Product_ID)
	{
		if (!isset($_SESSION['ShoppingCart']))
			return -1;
			
		$size=count($_SESSION['ShoppingCart']);
		
		if ($size==0)
			return -1;
			
		for ($i=0;$i<$size;$i++)
		{
			if ($Product_ID==$_SESSION['ShoppingCart'][$i]['Product_ID'])
				return $i;
		}
		
		return -1;
	}			
}
?>