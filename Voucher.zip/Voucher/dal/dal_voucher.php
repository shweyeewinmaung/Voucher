<?php
function GetVoucherByVoucherID($conn,$Voucher_ID)
{
	$sql="SELECT * FROM tbl_voucher WHERE Voucher_ID='$Voucher_ID' ";
	
	return mysqli_query($conn,$sql);
}

function UpdateVoucher($conn,$Voucher_ID, $Voucher_Date,$Customer_ID,$Payment_Status,$Order_Code,$Status,$Delivery_Price)
{
	$sql="UPDATE tbl_voucher SET Voucher_Date='$Voucher_Date' ,
								 Customer_ID='$Customer_ID' ,
								 Payment_Status='$Payment_Status' ,
								 Order_Code='$Order_Code' ,
								 Status='$Status' ,
								  Delivery_Price='$Delivery_Price' 
							
							WHERE Voucher_ID='$Voucher_ID'";
	mysqli_query($conn,$sql);
}

function DeleteVoucher($conn,$Voucher_ID)
{
	$sql="DELETE FROM tbl_voucher WHERE Voucher_ID='$Voucher_ID'";
	$sql1="DELETE FROM tbl_voucherdetail WHERE Voucher_ID='$Voucher_ID'";
	mysqli_query($conn,$sql);
	mysqli_query($conn,$sql1);
}
?>