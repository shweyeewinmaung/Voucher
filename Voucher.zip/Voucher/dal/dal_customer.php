<?php

function GetCustomerDataByCustomer($conn)
{
	$sql="SELECT * FROM tbl_customer order by Customer_ID desc";
	return mysqli_query($conn,$sql);
}
function GetCustomerDataBy_CustomerName($conn,$Customer_Name)
{
	$sql="SELECT * FROM tbl_customer WHERE Customer_Name='$Customer_Name'";
	$ret=mysqli_query($conn,$sql);
	return $ret;
}

function GetCustomerDataBy_CustomerPhone($conn,$Customer_Phone)
{
	$sql="SELECT * FROM tbl_customer WHERE Customer_Phone='$Customer_Phone'";
	$ret=mysqli_query($conn,$sql);
	return $ret;
}

function GetCustomerDataByCustomerID($conn,$Customer_ID)
{
	$sql="SELECT * FROM tbl_customer WHERE Customer_ID='$Customer_ID'";
	return mysqli_query($conn,$sql);
}
function GetVoucherDataByCustomerID($conn,$Customer_ID)
{
	$sql="SELECT * FROM tbl_voucher WHERE Customer_ID='$Customer_ID' order by Voucher_ID desc";
	
	return mysqli_query($conn,$sql);
}
function GetVoucherDataByVoucherID($conn,$Voucher_ID)
{
	$sql="SELECT * FROM tbl_voucherdetail WHERE Voucher_ID='$Voucher_ID' ";
	
	return mysqli_query($conn,$sql);
}
function GetVoucherDataByVoucher($conn)
{
	$sql="SELECT * FROM tbl_voucher order by Voucher_ID desc";
	return mysqli_query($conn,$sql);
}

function GetCustomerNameByCustomerID($conn,$Customer_ID)
{
	$sql="SELECT * FROM tbl_customer WHERE Customer_ID='$Customer_ID'";
	$ret=mysqli_query($conn,$sql);
	$row=mysqli_fetch_array($ret);
	
	return $row['1'];
}
function InsertCustomer($conn,$Customer_ID, $Customer_Name, $Customer_Phone, $Customer_Email,$Customer_Address)
{
	$sql="INSERT INTO tbl_customer(Customer_ID, Customer_Name, Customer_Phone, Customer_Email,Customer_Address) 
			VALUES('$Customer_ID', '$Customer_Name', '$Customer_Phone', '$Customer_Email', '$Customer_Address')";
			
	mysqli_query($conn,$sql);
}
function UpdateCustomer($conn,$Customer_ID, $Customer_Name, $Customer_Phone, $Customer_Email,$Customer_Address)
{
	$sql="UPDATE tbl_customer SET Customer_Name='$Customer_Name', 
							  Customer_Phone='$Customer_Phone',
							  Customer_Email='$Customer_Email', 
							  Customer_Address='$Customer_Address'
							 
							WHERE Customer_ID='$Customer_ID'";
							echo $sql;
	mysqli_query($conn,$sql);
}

function DeleteCustomer($conn,$Customer_ID)
{
	$sql="DELETE FROM tbl_customer WHERE Customer_ID='$Customer_ID'";
	mysqli_query($conn,$sql);
}
?>