<?php

function GetSupplierDataBySupplier($conn)
{
	$sql="SELECT * FROM tbl_supplier order by Supplier_ID desc";
	return mysqli_query($conn,$sql);
}
function GetSupplierDataBy_SupplierName($conn,$Supplier_Name)
{
	$sql="SELECT * FROM tbl_supplier WHERE Supplier_Name='$Supplier_Name'";
	$ret=mysqli_query($conn,$sql);
	return $ret;
}
function GetSupplierDataBySupplierID($conn,$Supplier_ID)
{
	$sql="SELECT * FROM tbl_supplier WHERE Supplier_ID='$Supplier_ID'";
	return mysqli_query($conn,$sql);
}
function GetSupplierNameBySupplierID($conn,$Supplier_ID)
{
	$sql="SELECT * FROM tbl_supplier WHERE Supplier_ID='$Supplier_ID'";
	$ret=mysqli_query($conn,$sql);
	$row=mysqli_fetch_array($ret);
	
	return $row['1'];
}
function InsertSupplier($conn,$Supplier_ID, $Supplier_Name, $Supplier_Phone, $Supplier_Email,$Supplier_Address)
{
	$sql="INSERT INTO tbl_supplier(Supplier_ID, Supplier_Name, Supplier_Phone, Supplier_Email,Supplier_Address) 
			VALUES('$Supplier_ID', '$Supplier_Name', '$Supplier_Phone', '$Supplier_Email', '$Supplier_Address')";
	mysqli_query($conn,$sql);
}
function UpdateSupplier($conn,$Supplier_ID, $Supplier_Name, $Supplier_Phone, $Supplier_Email,$Supplier_Address)
{
	$sql="UPDATE tbl_supplier SET Supplier_Name='$Supplier_Name', 
							  Supplier_Phone='$Supplier_Phone',
							  Supplier_Email='$Supplier_Email', 
							  Supplier_Address='$Supplier_Address'
							 
							WHERE Supplier_ID='$Supplier_ID'";
	mysqli_query($conn,$sql);
}
function DeleteSupplier($conn,$Supplier_ID)
{
	$sql="DELETE FROM tbl_supplier WHERE Supplier_ID='$Supplier_ID'";
	mysqli_query($conn,$sql);
}
?>