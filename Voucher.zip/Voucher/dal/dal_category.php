<?php

function GetCategoryDataByCategory($conn)
{
	$sql="SELECT * FROM tbl_category order by Category_ID desc";
	return mysqli_query($conn,$sql);
}
function GetCategoryNameByCategory($conn)
{
	$sql="SELECT Distinct(Category_Name) FROM tbl_category";
	return mysqli_query($conn,$sql);
}
function GetCategoryDataBy_CategoryName($conn,$Category_Name)
{
	$sql="SELECT * FROM tbl_category WHERE Category_Name='$Category_Name'";
	$ret=mysqli_query($conn,$sql);
	return $ret;
}

function GetCategoryNameByCategoryID($conn,$Category_ID)
{
	$sql="SELECT * FROM tbl_category WHERE Category_ID='$Category_ID'";
	$ret=mysqli_query($conn,$sql);
	$row=mysqli_fetch_array($ret);
	
	return $row['1'];
}
function GetCategoryDataByCategoryID($conn,$Category_ID)
{
	$sql="SELECT * FROM tbl_category WHERE Category_ID='$Category_ID'";
	return mysqli_query($conn,$sql);
}
function InsertCategory($conn,$Category_ID, $Category_Name)
{
	$sql="INSERT INTO tbl_category(Category_ID, Category_Name) 
			VALUES('$Category_ID', '$Category_Name')";
	mysqli_query($conn,$sql);
}
function UpdateCategory($conn,$Category_ID, $Category_Name)
{
	$sql="UPDATE tbl_category SET Category_Name='$Category_Name' 
							
							WHERE Category_ID='$Category_ID'";
	mysqli_query($conn,$sql);
}
function DeleteCategory($conn,$Category_ID)
{
	$sql="DELETE FROM tbl_category WHERE Category_ID='$Category_ID'";
	mysqli_query($conn,$sql);
}
?>