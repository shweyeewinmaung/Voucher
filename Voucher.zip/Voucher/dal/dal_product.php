<?php
function GetProductDataByProduct($conn)
{
	$sql="SELECT * FROM tbl_product order by Product_ID desc";
	return mysqli_query($conn,$sql);
}
function GetProductDataBy_ProductName($conn,$Product_Name)
{
	$sql="SELECT * FROM tbl_product WHERE Product_Name='$Product_Name'";
	$ret=mysqli_query($conn,$sql);
	return $ret;
}
function GetProductDataByProductID($conn,$Product_ID)
{
	$sql="SELECT * FROM tbl_product WHERE Product_ID='$Product_ID'";
	return mysqli_query($conn,$sql);
}

function InsertProduct($conn,$Product_ID, $Product_Name,$Product_Code,$Category_ID,$Original_Price,$Selling_Price)
{
	$sql="INSERT INTO tbl_product(Product_ID, Product_Name,Product_Code,Category_ID,Original_Price,Selling_Price) 
			VALUES('$Product_ID', '$Product_Name', '$Product_Code', '$Category_ID','$Original_Price','$Selling_Price')";
	mysqli_query($conn,$sql);
}
function UpdateProduct($conn,$Product_ID, $Product_Name,$Product_Code,$Category_ID,$Original_Price,$Selling_Price)
{
	$sql="UPDATE tbl_product SET Product_Name='$Product_Name' ,
								 Product_Code='$Product_Code' ,
								 Category_ID='$Category_ID' ,
								 Original_Price='$Original_Price' ,
								 Selling_Price='$Selling_Price' 
							
							WHERE Product_ID='$Product_ID'";
	mysqli_query($conn,$sql);
}
function DeleteProduct($conn,$Product_ID)
{
	$sql="DELETE FROM tbl_product WHERE Product_ID='$Product_ID'";
	mysqli_query($conn,$sql);
}
?>