<?php
if(!$_SESSION['SESS']['User'])
{
	header("Location:../../LogIn");
}
?>