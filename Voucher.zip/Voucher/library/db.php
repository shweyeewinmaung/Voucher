<?php
$host="localhost";
$username="root";
$password="";
$database="enfantodb";

$conn = mysqli_connect($host, $username, $password) or die(mysql_error());
mysqli_select_db($conn,$database) or die(mysql_error());
?>