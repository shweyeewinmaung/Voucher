-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2017 at 09:27 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enfantodb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `Category_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Category_Name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`Category_ID`, `Category_Name`) VALUES
('CG-000001', 'á€±á€›á€á€ºá€­á€³á€¸á€†á€•á€¹á€»á€•á€¬á€›á€Šá€¹'),
('CG-000002', 'á€á€›á€„á€¹á€™á€¹'),
('CG-000003', 'á€œá€­á€¯á€¸á€›á€½á€„á€¹á€¸'),
('CG-000004', 'á€¡á€œá€½á€†á€®'),
('CG-000005', 'á€±á€•á€«á€„á€¹á€’á€«'),
('CG-000006', 'á€±á€á€«á€„á€¹á€¸á€±á€œá€½á€½á€ºá€¬á€¹á€›á€Šá€¹'),
('CG-000007', 'á€±á€›á€á€ºá€­á€³á€¸á€†á€•á€¹á€»á€•á€¬'),
('CG-000008', 'á€™á€ºá€€á€¹á€”á€½á€¬á€žá€¯á€á€¹á€•á€¯á€á€«'),
('CG-000009', 'Happy Time á€¡á€šá€¹á€’á€®á€á€¬á€¡á€»á€€á€­á€¯á€€á€¹á€…á€¬á€¡á€¯á€•á€¹á€™á€ºá€¬á€¸'),
('CG-000010', 'Happy Time á€˜á€¬á€žá€¬á€”á€½á€…á€¹á€™á€ºá€­á€³á€¸ á€‡á€¬á€á€¹á€œá€™á€¹á€¸á€á€¼á€²'),
('CG-000011', 'Happy Time á€˜á€¬á€žá€¬á€”á€½á€…á€¹á€™á€ºá€­á€³á€¸ á€•á€¯á€¶á€»á€•á€„á€¹á€™á€ºá€¬á€¸'),
('CG-000012', 'á€žá€Šá€¹á€¸á€‘á€­á€á€¹á€›á€„á€¹á€–á€­á€¯ á€•á€¶á€¯á€»á€•á€„á€¹á€™á€ºá€¬á€¸'),
('CG-000013', 'á€žá€€á€¹á€¥á€®á€¸á€œá€¼á€„á€¹á€±á€á€á€¹ á€•á€¶á€¯á€»á€•á€„á€¹á€™á€ºá€¬á€¸'),
('CG-000014', 'á€’á€­á€¯á€€á€¹á€•á€«'),
('CG-000015', 'á€’á€­á€¯á€€á€¹á€•á€«á€¡á€­á€á€¹'),
('CG-000016', 'á€€á€±á€œá€¸á€˜á€­á€¯á€‘á€­á€¯á€„á€¹ á€¡á€­á€™á€¹á€žá€¬á€¡á€­á€¯á€¸'),
('CG-000017', 'á€¡á€”á€½á€®á€¸á€±á€œá€¬á€„á€¹á€œá€­á€™á€¹á€¸ á€á€›á€„á€¹á€™á€¹'),
('CG-000018', 'á€á€…á€¹á€›á‚ˆá€¸'),
('CG-000019', 'á€”á€­á€¯á‚•á€—á€°á€¸á€™á€ºá€¬á€¸'),
('CG-000020', 'á€”á€­á€¯á‚•á€™á‚ˆá€”á€¹á‚•á€™á€ºá€¬á€¸'),
('CG-000021', 'á€‡á€¼á€”á€¹á€¸áŠá€•á€”á€¹á€¸á€€á€”á€¹áŠá€á€¼á€€á€¹á€™á€ºá€¬á€¸'),
('CG-000022', 'á€»á€–á€Šá€¹á€·á€…á€¼á€€á€¹á€…á€¬á€™á€ºá€¬á€¸'),
('CG-000023', 'á€±á€†á€¸á€•á€…á¥á€Šá€¹á€¸á€™á€ºá€¬á€¸'),
('CG-000024', 'Personal Care'),
('CG-000025', 'á€á€¶á€á€¼á€„á€¹á€¸á€žá€”á€¹á‚•á€›á€½á€„á€¹á€¸á€±á€›á€¸'),
('CG-000026', 'á€žá€„á€¹á€±á€‘á€¬á€€á€¹á€€á€° á€€á€…á€¬á€¸á€…á€›á€¬á€™á€ºá€¬á€¸'),
('CG-000027', 'á€¡á€›á€¯á€•á€¹á€™á€ºá€¬á€¸'),
('CG-000028', 'á€»á€–á€³á€á€¹á€†á€€á€¹á€€á€…á€¬á€¸á€…á€›á€¬á€™á€ºá€¬á€¸'),
('CG-000029', 'á€”á€­á€¯á‚•á€›á€Šá€¹á€žá€­á€™á€¹á€¸á€¡á€­á€á€¹'),
('CG-000030', 'á€»á€–á€Šá€¹á€·á€…á€¼á€€á€¹á€…á€¬á€¡á€á€¼á€€á€¹ á€¡á€žá€¶á€¯á€¸á€»á€•á€³á€›á€±á€žá€¬ á€•á€…á¥á€Šá€¹á€¸á€™á€ºá€¬á€¸'),
('CG-000031', 'á€á€¼á€”á€¹á€¸á€œá€½á€Šá€¹á€¸á€™á€ºá€¬á€¸'),
('CG-000032', 'á€œá€™á€¹á€¸á€±á€œá€½á€ºá€¬á€€á€¹á€€á€ºá€„á€¹á€·á€á€¼á€”á€¹á€¸á€œá€½á€Šá€¹á€¸á€™á€ºá€¬á€¸'),
('CG-000033', 'á€€á€±á€œá€¸á€‘á€­á€¯á€„á€¹á€á€¶á€¯á€™á€ºá€¬á€¸'),
('CG-000034', 'á€€á€¬á€¸á€¡á€á€¼á€„á€¹á€¸á€žá€¶á€¯á€¸á€‘á€­á€¯á€„á€¹á€á€¶á€¯á€™á€ºá€¬á€¸'),
('CG-000035', 'á€•á€¯á€á€€á€¹á€”á€½á€„á€¹á€·á€€á€¯á€á€„á€¹á€™á€ºá€¬á€¸'),
('CG-000036', 'á€¡á€á€á€¹á€¡á€…á€¬á€¸á€™á€ºá€¬á€¸'),
('CG-000037', 'á€–á€­á€”á€•á€¹á€™á€ºá€¬á€¸'),
('CG-000038', 'á€–á€€á€¹á€›á€½á€„á€¹á€†á€€á€¹á€…á€•á€¹ á€•á€…á¥á€Šá€¹á€¸á€™á€ºá€¬á€¸'),
('CG-000039', 'á€¡á€­á€á€¹á€™á€ºá€¬á€¸'),
('CG-000040', 'á€á€€á€­á€¯á€šá€¹á€›á€Šá€¹ á€žá€”á€¹á‚•á€›á€½á€„á€¹á€¸á€™á‚ˆ'),
('CG-000041', 'á€±á€™á€±á€™ á€á€­á€¯á€·á€¡á€á€¼á€€á€¹ á€á€€á€¯á€­á€šá€¹á€›á€Šá€¹á€žá€”á€¹á‚•á€›á€½á€„á€¹á€¸á€™á‚ˆ'),
('CG-000042', 'á€±á€™á€±á€™á€á€­á€¯á€·á€¡á€á€¼á€€á€¹ á€¡á€á€á€¹á€¡á€…á€¬á€¸á€™á€ºá€¬á€¸'),
('CG-000043', 'á€±á€™á€±á€™ á€á€­á€¯á€·á€¡á€á€¼á€€á€¹ á€±á€†á€¸á€•á€…á¥á€Šá€¹á€¸á€™á€ºá€¬á€¸'),
('CG-000044', 'á€±á€™á€±á€™ á€á€­á€¯á€·á€¡á€á€¼á€€á€¹  á€»á€–á€Šá€¹á€·á€…á€¼á€€á€¹á€…á€¬á€™á€ºá€¬á€¸'),
('CG-000045', 'á€”á€­á€¯á‚•á€á€­á€¯á€€á€¹á€™á€­á€á€„á€¹ á€¡á€žá€¶á€¯á€¸á€¡á€±á€†á€¬á€„á€¹á€™á€ºá€¬á€¸'),
('CG-000046', 'á€€á€­á€¯á€šá€¹á€á€”á€¹á€±á€†á€¬á€„á€¹á€™á€­á€á€„á€¹ á€¡á€žá€¶á€¯á€¸á€¡á€±á€†á€¬á€„á€¹á€™á€ºá€¬á€¸');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `Customer_ID` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Customer_Name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Customer_Phone` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Customer_Email` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Customer_Address` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`Customer_ID`, `Customer_Name`, `Customer_Phone`, `Customer_Email`, `Customer_Address`) VALUES
('C-000001', 'Aye Aye', '09425272829', 'aa@gmail.com', 'Yangon'),
('C-000002', 'aaa', '0966666666666', 'aa@gmail.com', 'Yangon');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `Product_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Product_Name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Product_Code` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Category_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Original_Price` int(50) NOT NULL,
  `Selling_Price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`Product_ID`, `Product_Name`, `Product_Code`, `Category_ID`, `Original_Price`, `Selling_Price`) VALUES
('P-000001', 'Baby Mind Shampoo', 'A-001', 'CG-000006', 2000, 2200),
('P-000002', 'Baby Mind Lotion', 'A-002', 'CG-000003', 2500, 2800),
('P-000003', 'Baby Mind Bath Shower', 'A-003', 'CG-000001', 2100, 2400),
('P-000004', 'Babi Mild â€“ Mild Kids 2 in 1 Bath (Mixed Berries)', 'A-004', 'CG-000001', 4000, 4250),
('P-000005', 'Babi Mild â€“ Mild Kids 3 in 1 (Strawberry Yoghurt Smoothie)', 'A-004', 'CG-000001', 4000, 4250),
('P-000006', 'Babi Mild â€“ Soap', 'A-005', 'CG-000007', 500, 540),
('P-000007', 'aaaa', 'aaaa', 'CG-000036', 300, 400);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supplier`
--

CREATE TABLE `tbl_supplier` (
  `Supplier_ID` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Supplier_Name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Supplier_Phone` int(20) NOT NULL,
  `Supplier_Email` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Supplier_Address` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_supplier`
--

INSERT INTO `tbl_supplier` (`Supplier_ID`, `Supplier_Name`, `Supplier_Phone`, `Supplier_Email`, `Supplier_Address`) VALUES
('C-000001', 'In Stock', 2147483647, 'instock@gmail.com', 'UMG'),
('C-000002', 'Baby Mine', 98888888, 'babymild@gmail.com', 'Yangon'),
('C-000003', 'City Mart', 99999999, 'citymart@gmail.com', 'Yangon');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `User_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `User_Name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `User_Email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `User_Password` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `User_Role` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `Created_Date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Lastin_Date` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`User_ID`, `User_Name`, `User_Email`, `User_Password`, `User_Role`, `Created_Date`, `Lastin_Date`) VALUES
('U-000001', 'aa', 'aa@gmail.com', 'aa', 'Manager', '21-Oct-2017', '26-10-2017'),
('U-000002', 'Aye Aye', 'ayeaye@gmail.com', 'ayeaye', 'Manager', '30-10-2017', '30-10-2017'),
('U-000003', 'Su Su', 'susu@gmail.com', 'susu', 'Manager', '30-10-2017', '30-10-2017'),
('U-000004', 'Aung Aung', 'aungaung@gmail.com', 'aungaung', 'Manager', '30-10-2017', '30-10-2017'),
('U-000005', 'Mg Mg', 'mgmg@gmail.com', 'mgmg', 'Manager', '30-10-2017', '30-10-2017');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_voucher`
--

CREATE TABLE `tbl_voucher` (
  `Voucher_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Voucher_Date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `User_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Customer_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Payment_Status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Order_Code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Delivery_Price` int(255) NOT NULL,
  `Amount` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_voucher`
--

INSERT INTO `tbl_voucher` (`Voucher_ID`, `Voucher_Date`, `User_ID`, `Customer_ID`, `Payment_Status`, `Order_Code`, `Status`, `Delivery_Price`, `Amount`) VALUES
('V-000002', '2-Nov-2017', 'U-000001', 'C-000001', 'UMG Office', '#2222', 'Done', 3000, 26320),
('V-000003', '31-Oct-2017', 'U-000001', 'C-000001', 'UMG Office', '#1111', 'Done', 3000, 800),
('V-000004', '31-Oct-2017', 'U-000001', 'C-000002', 'UMG Office', '2222', 'Done', 2000, 120300);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_voucherdetail`
--

CREATE TABLE `tbl_voucherdetail` (
  `Voucher_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Product_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Quantity` int(255) NOT NULL,
  `Selling_Price` int(255) NOT NULL,
  `Discount_Price` int(255) NOT NULL,
  `Supplier_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_voucherdetail`
--

INSERT INTO `tbl_voucherdetail` (`Voucher_ID`, `Product_ID`, `Quantity`, `Selling_Price`, `Discount_Price`, `Supplier_ID`) VALUES
('V-000002', 'P-000006', 33, 540, 0, 'C-000003'),
('V-000002', 'P-000005', 2, 4250, 0, 'C-000003'),
('V-000003', 'P-000007', 2, 400, 0, 'C-000001'),
('V-000004', 'P-000007', 3, 400, 0, 'C-000003'),
('V-000004', 'P-000001', 2, 2200, 0, 'C-000003'),
('V-000004', 'P-000002', 5, 2800, 0, 'C-000002'),
('V-000004', 'P-000003', 3, 2400, 0, 'C-000003'),
('V-000004', 'P-000004', 22, 4250, 0, 'C-000003');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
